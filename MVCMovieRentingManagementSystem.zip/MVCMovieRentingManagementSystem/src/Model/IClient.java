package Model;

import java.util.ArrayList;
import View.ICreateClientPageGUI;
import View.IDeleteClientPageGUI;
import View.ISearchClientPageGUI;
import View.IDisplayClientsPageGUI;

/**
 *
 * @author Nithisha Reddy Boyapati
 */
public interface IClient {

    public void registerObserver(ISearchClientPageGUI observer);

    public void registerObserver(IDisplayClientsPageGUI observer);

    public void registerObserver(IDeleteClientPageGUI observer);

    public void removeObserver(IDeleteClientPageGUI observer);

    public void registerObserver(ICreateClientPageGUI observer);

    public void removeObserver(ICreateClientPageGUI observer);

    public void setResultClients(ArrayList<Client> resultClients);

    public ArrayList<Client> getResultClients();

    public ArrayList<Client> searchByFirstName(String fileName, String firstName);

    public ArrayList<Client> searchByLastName(String fileName, String lastName);

    public ArrayList<Client> searchByName(String fileName, String firstName, String lastName);

    public int createClient(String fileName, String firstName, String lastName);

    public void deleteClient(String fileName, int client_id);

    public ArrayList<Client> showClients(String fileName);
    
   

    public ArrayList<Client> getClients();

    public void setClients(ArrayList<Client> clients);

    public int getClient_id();

    public void setClient_id(int client_id);

    public String getName();

    public void setName(String name);

    public String getDeleted();

    public void setDeleted(String deleted);

}
