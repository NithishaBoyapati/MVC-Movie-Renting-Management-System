package Model;

import java.util.ArrayList;
import View.IAddMoviePageGUI;
import View.IDisplayMoviesPageGUI;

/**
 *
 * @author Nithisha Reddy Boyapati
 */
public interface IMovie {

    public void registerObserver(IDisplayMoviesPageGUI observer);

    public void removeObserver(IDisplayMoviesPageGUI observer);

    public void registerObserver(IAddMoviePageGUI observer);

    public void removeObserver(IAddMoviePageGUI observer);

    public void rentMovieUpdate(String fileName, int movie_id, String flag);

    public ArrayList<Movie> getMovies();

    public ArrayList<Movie> showMovies(String fileName);

    public ArrayList<Movie> showCurrentRentedMovies(String fileName);

    public void setMovies(ArrayList<Movie> movies);

    public int addMovie(String fileName, String movieTitle);

    public int getMovie_id();

    public void setMovie_id(int movie_id);

    public String getMovie_title();

    public void setMovie_title(String movie_title);

    public String getRent();

    public void setRent(String rent);


}
