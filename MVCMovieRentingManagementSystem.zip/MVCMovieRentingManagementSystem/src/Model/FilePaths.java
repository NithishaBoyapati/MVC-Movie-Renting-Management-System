package Model;

import java.util.ArrayList;
import View.ISelectFilesPageGUI;
import View.IHomePageGUI;

/**
 *
 * @author Nithisha Reddy Boyapati
 */
public class FilePaths implements IFilePaths {

    ArrayList filePathsObservers = new ArrayList();
    String movieFilePath;
    String clientFilePath;
    String rentingFilePath;

    @Override
    public String getRentingFilePath() {
        return rentingFilePath;
    }

    @Override
    public void setRentingFilePath(String rentingFilePath) {
        this.rentingFilePath = rentingFilePath;
    }
    
     @Override
    public void registerObserver(IHomePageGUI homeObserver) {
        filePathsObservers.add(homeObserver);
    }

    @Override
    public void registerObserver(ISelectFilesPageGUI filePathObserver) {
        filePathsObservers.add(filePathObserver);
    }

    @Override
    public void removeObserver(ISelectFilesPageGUI filePathObserver) {
        int i = filePathsObservers.indexOf(filePathObserver);
        if (i >= 0) {
            filePathsObservers.remove(filePathObserver);
        }
    }

    @Override
    public String getMovieFilePath() {
        return movieFilePath;
    }

    @Override
    public void setMovieFilePath(String movieFilePath) {
        this.movieFilePath = movieFilePath;
    }

    @Override
    public String getClientFilePath() {
        return clientFilePath;
    }

    @Override
    public void setClientFilePath(String clientFilePath) {
        this.clientFilePath = clientFilePath;
    }

}
