package Model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import View.IAddMoviePageGUI;
import View.IDisplayMoviesPageGUI;

/**
 *
 * @author  Nithisha Reddy Boyapati
 */
public class Movie implements IMovie {

    ArrayList movieObservers = new ArrayList();
    ArrayList<Movie> movies = new ArrayList<Movie>();
    ArrayList<Movie> currentRentedMovies = new ArrayList<Movie>();
    int movie_id;
    String movie_title;
    String rent;

    public Movie() {

    }

    public Movie(String movie_title, int movie_id, String rent) {
        this.movie_id = movie_id;
        this.movie_title = movie_title;
        this.rent = rent;
    }

  

    @Override
    public ArrayList<Movie> showMovies(String fileName) {
        try {
            movies.clear();
            BufferedReader br = new BufferedReader(new FileReader(fileName));
            String line = "";
            String cvsSplitBy = ";";
            int linecount = 1;
            while ((line = br.readLine()) != null) {

                String[] movie = line.split(cvsSplitBy);
                Movie newMovie;
                if (linecount != 1) {
                    newMovie = new Movie(movie[0],Integer.parseInt(movie[1]), movie[2]);
                    movies.add(newMovie);
                }
                linecount++;
            }
            return movies;
        } catch (FileNotFoundException ex) {

        } catch (IOException ex) {

        }
        return movies;
    }

    @Override
    public ArrayList<Movie> showCurrentRentedMovies(String fileName) {
        movies = showMovies(fileName);
        currentRentedMovies.clear();
        
        for (Movie movie : movies) {
            if (movie.rent.equalsIgnoreCase("True")) {
                currentRentedMovies.add(movie);
            }
        }

        return currentRentedMovies;
    }

    @Override
    public ArrayList<Movie> getMovies() {
        return movies;
    }

    @Override
    public void setMovies(ArrayList<Movie> movies) {
        this.movies = movies;
    }

    @Override
    public void rentMovieUpdate(String fileName, int movie_id, String flag) {
        movies = showMovies(fileName);

        for (Movie movie : movies) {
            if (movie.getMovie_id() == movie_id) {
                movie.setRent(flag);
            }
        }

        
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(fileName))) {
            bw.write("movie_title;movie_id;rented");
            for (Movie movie : movies) {
                bw.newLine();
                bw.write(movie.getMovie_title() + ";" + movie.getMovie_id() + ";" + movie.getRent());
            }

            bw.close();

        } catch (IOException ex) {

        }
    }

    @Override
    public int addMovie(String fileName, String movieTitle) {
        movies = showMovies(fileName);
        boolean existingMovie = false;

        
        for (Movie movie : movies) {
            if (movie.getMovie_title().toLowerCase().equals(movieTitle.toLowerCase())) {
                existingMovie = true;
                return 0;
            }
        }

        
        int id = 10 + movies.size() * 10;
        String newMovie =  movieTitle + ";" + id + ";" + "False";
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(fileName, true))) {
            bw.newLine();
            bw.write(newMovie);
            bw.close();
            return id;
        } catch (IOException ex) {

        }

        return 0;

    }

    @Override
    public void registerObserver(IDisplayMoviesPageGUI movieObserver) {
        movieObservers.add(movieObserver);
    }

    @Override
    public void removeObserver(IDisplayMoviesPageGUI movieObserver) {
        int i = movieObservers.indexOf(movieObserver);
        if (i >= 0) {
            movieObservers.remove(movieObserver);
        }
    }

    @Override
    public void registerObserver(IAddMoviePageGUI movieObserver) {
        movieObservers.add(movieObserver);
    }

    @Override
    public void removeObserver(IAddMoviePageGUI movieObserver) {
        int i = movieObservers.indexOf(movieObserver);
        if (i >= 0) {
            movieObservers.remove(movieObserver);
        }
    }

    @Override
    public int getMovie_id() {
        return movie_id;
    }

    @Override
    public void setMovie_id(int movie_id) {
        this.movie_id = movie_id;
    }

    @Override
    public String getMovie_title() {
        return movie_title;
    }

    @Override
    public void setMovie_title(String movie_title) {
        this.movie_title = movie_title;
    }

    @Override
    public String getRent() {
        return rent;
    }

    @Override
    public void setRent(String rent) {
        this.rent = rent;
    }

}
