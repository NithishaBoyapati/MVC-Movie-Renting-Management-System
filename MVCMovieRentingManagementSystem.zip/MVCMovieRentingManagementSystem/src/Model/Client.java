
package Model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import View.ICreateClientPageGUI;
import View.IDeleteClientPageGUI;
import View.ISearchClientPageGUI;
import View.IDisplayClientsPageGUI;

/**
 *
 * @author Nithisha Reddy Boyapati
 */
public class Client implements IClient {

    ArrayList clientObservers = new ArrayList();
    ArrayList<Client> clients = new ArrayList<Client>();
    ArrayList<Client> resultClients = new ArrayList<Client>();
    int client_id;
    String name;
    String deleted;

    public Client() {

    }

    public Client(String name, int client_id, String deleted) {

        this.client_id = client_id;
        this.name = name;
        this.deleted = deleted;
    
    }
    
    @Override
    public void registerObserver(ISearchClientPageGUI clientObserver) {
        clientObservers.add(clientObserver);
    }

     @Override
    public ArrayList<Client> getResultClients() {
        return resultClients;
    }

     @Override
    public void setResultClients(ArrayList<Client> resultClients) {
        this.resultClients = resultClients;
    }


    @Override
    public void registerObserver(IDisplayClientsPageGUI clientObserver) {
        clientObservers.add(clientObserver);
    }

    @Override
    public void registerObserver(IDeleteClientPageGUI clientObserver) {
        clientObservers.add(clientObserver);
    }

    @Override
    public void removeObserver(IDeleteClientPageGUI clientObserver) {
        int i = clientObservers.indexOf(clientObserver);
        if (i >= 0) {
            clientObservers.remove(clientObserver);
        }
    }

    @Override
    public void registerObserver(ICreateClientPageGUI clientObserver) {
        clientObservers.add(clientObserver);
    }

    @Override
    public void removeObserver(ICreateClientPageGUI clientObserver) {
        int i = clientObservers.indexOf(clientObserver);
        if (i >= 0) {
            clientObservers.remove(clientObserver);
        }
    }

    @Override
    public ArrayList<Client> showClients(String fileName) {
        try {
            clients.clear();
            BufferedReader br = new BufferedReader(new FileReader(fileName));
            String line = "";
            String cvsSplitBy = ";";
            int linecount = 1;
            while ((line = br.readLine()) != null) {

                String[] client = line.split(cvsSplitBy);
                Client newClient;
                if (linecount != 1) {
                    newClient = new Client(client[0],Integer.parseInt(client[1]),client[2]);
                    clients.add(newClient);
                }
                linecount++;
            }
            return clients;
        } catch (FileNotFoundException ex) {

        } catch (IOException ex) {

        }
        return clients;
    }
    
    
   public ArrayList<Client> showActiveClients(String fileName) {
         try {
            clients.clear();
            BufferedReader br = new BufferedReader(new FileReader(fileName));
            String line = "";
            String cvsSplitBy = ";";
            int linecount = 1;
            while ((line = br.readLine()) != null) {

                String[] client = line.split(cvsSplitBy);
                Client newClient;
                if (linecount != 1) {
                    if(client[2].equalsIgnoreCase("False")) {
                    newClient = new Client(client[0],Integer.parseInt(client[1]),client[2]);
                    clients.add(newClient);
                    }
                }
                linecount++;
            }
            return clients;
        } catch (FileNotFoundException ex) {

        } catch (IOException ex) {

        }
        return clients;
   }
            

    @Override
    public ArrayList<Client> searchByFirstName(String fileName, String firstName) {
        clients = showClients(fileName);
        resultClients.clear();
        for (Client client : clients) {

            if (client.getName().toLowerCase().startsWith(firstName.toLowerCase())) {
                resultClients.add(client);
            }
        }
        return resultClients;
    }

    @Override
    public ArrayList<Client> searchByLastName(String fileName, String lastName) {
        clients = showClients(fileName);
        resultClients.clear();
        for (Client client : clients) {
            String fullname = client.getName().toLowerCase();
            if (fullname.substring(fullname.indexOf(" ") + 1).startsWith(lastName.toLowerCase())) {
                resultClients.add(client);
            }
        }
        return resultClients;
    }

    @Override
    public ArrayList<Client> searchByName(String fileName, String firstName, String lastName) {
        clients = showClients(fileName);
        resultClients.clear();
        for (Client client : clients) {
            String fullname = client.getName().toLowerCase();
            if (fullname.startsWith(firstName.toLowerCase())
                    && fullname.substring(fullname.indexOf(" ") + 1).startsWith(lastName.toLowerCase())) {
                resultClients.add(client);
            }
        }
        return resultClients;
    }

    @Override
    public void deleteClient(String fileName, int client_id) {
        clients = showClients(fileName);

        for (Client client : clients) {
            if (client.getClient_id() == client_id) {
                client.setDeleted("True");
            }
        }

        
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(fileName))) {
            bw.write("name;client_id; deleted");
            for (Client client : clients) {
                bw.newLine();
                bw.write(client.getName() + ";" + client.getClient_id() + ";" + client.getDeleted());
            }

            bw.close();

        } catch (IOException ex) {

        }
    }

    @Override
    public int createClient(String fileName, String firstName, String lastName) {
        clients = showClients(fileName);
        boolean existingClient = false;
        String fullname = firstName + " " + lastName;

        
        for (Client client : clients) {
            if (client.getName().toLowerCase().equals(fullname.toLowerCase())) {
                existingClient = true;
                return 0;
            }
        }

        
        int id = clients.size() + 1;
        String newClient = firstName + " " + lastName + ";" + id + ";" + "False";
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(fileName, true))) {
            bw.newLine();
            bw.write(newClient);
            bw.close();
            return id;
        } catch (IOException ex) {

        }

        return 0;

    }

    @Override
    public int getClient_id() {
        return client_id;
    }

    @Override
    public void setClient_id(int client_id) {
        this.client_id = client_id;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String getDeleted() {
        return deleted;
    }

    @Override
    public void setDeleted(String deleted) {
        this.deleted = deleted;
    }

    @Override
    public ArrayList<Client> getClients() {
        return clients;
    }

    @Override
    public void setClients(ArrayList<Client> clients) {
        this.clients = clients;
    }

}
