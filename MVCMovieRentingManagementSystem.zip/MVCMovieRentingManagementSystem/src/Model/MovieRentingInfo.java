package Model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import View.IRentMoviePageGUI;
import View.IReturnMoviePageGUI;
import View.IDisplayRentMovieHistoryPageGUI;

/**
 *
 * @author Nithisha Reddy Boyapati
 */
public class MovieRentingInfo implements IMovieRentingInfo, Comparable {

    ArrayList movieRentingInfoObservers = new ArrayList();
    ArrayList<MovieRentingInfo> movieRentings = new ArrayList<MovieRentingInfo>();
    ArrayList<MovieRentingInfo> currentRentMovieHistory = new ArrayList<MovieRentingInfo>();

    int renting_id;
    int client_id;
    int movie_id;
    String date_out;
    String date_in;
    int fine_amount;

    public MovieRentingInfo() {

    }

    public MovieRentingInfo(int renting_id, int client_id, int movie_id, String date_out, String date_in, int fine_amount) {
        this.renting_id = renting_id;
        this.client_id = client_id;
        this.movie_id = movie_id;
        this.date_out = date_out;
        this.date_in = date_in;
        this.fine_amount = fine_amount;
    }
    
    public MovieRentingInfo(String date_out, String date_in,int client_id,int movie_id,int renting_id) {
        this.renting_id = renting_id;
        this.client_id = client_id;
        this.movie_id = movie_id;
        this.date_out = date_out;
        this.date_in = date_in;
        this.fine_amount = fine_amount;
    }

    @Override
    public void registerObserver(IDisplayRentMovieHistoryPageGUI observer) {

        movieRentingInfoObservers.add(observer);
    }

    @Override
    public void removeObserver(IDisplayRentMovieHistoryPageGUI observer) {
        int i = movieRentingInfoObservers.indexOf(observer);
        if (i >= 0) {
            movieRentingInfoObservers.remove(observer);
        }
    }

    @Override
    public ArrayList<MovieRentingInfo> ShowCurrentRentMovieHistory(String fileName, int movie_id) {
        currentRentMovieHistory.clear();

        movieRentings = showMovieRentings(fileName);

        for (MovieRentingInfo movieRenting : movieRentings) {
            if (movieRenting.getMovie_id() == movie_id) {
                currentRentMovieHistory.add(movieRenting);
            }
        }
        return currentRentMovieHistory;
    }

    @Override
    public int compareTo(Object compareMovieRenting) {
        try {
            String date_in = ((MovieRentingInfo) compareMovieRenting).getDate_in();
            Date in = new SimpleDateFormat("MM/dd/yyyy").parse(date_in);

            String current_date_in = this.getDate_in();
            Date currentin = new SimpleDateFormat("MM/dd/yyyy").parse(current_date_in);

            return in.compareTo(currentin);
        } catch (ParseException ex) {

        }
        
        return 0;
    }

    @Override
    public ArrayList<MovieRentingInfo> getCurrentRentMovieHistory() {
        return currentRentMovieHistory;
    }

    @Override
    public void setCurrentRentMovieHistory(ArrayList<MovieRentingInfo> currentRentMovieHistory) {
        this.currentRentMovieHistory = currentRentMovieHistory;
    }

    @Override
    public ArrayList<MovieRentingInfo> showMovieRentings(String fileName) {
        try {
            movieRentings.clear();
            BufferedReader br = new BufferedReader(new FileReader(fileName));
            String line = "";
            String cvsSplitBy = ";";
            int linecount = 1;
            while ((line = br.readLine()) != null) {

                String[] movieRenting = line.split(cvsSplitBy);
                MovieRentingInfo newMovieRenting;
                if (linecount != 1) {
                     newMovieRenting = new MovieRentingInfo(movieRenting[0],movieRenting[1],Integer.parseInt(movieRenting[2]),
                            Integer.parseInt(movieRenting[3]),
                            Integer.parseInt(movieRenting[4])
                            );
                    movieRentings.add(newMovieRenting);
                }
                linecount++;
            }
            return movieRentings;
        } catch (FileNotFoundException ex) {

        } catch (IOException ex) {

        }
        return movieRentings;
    }

    @Override
    public void returnMovie(String fileName, int renting_id, String datein, int fineAmount) {
        movieRentings = showMovieRentings(fileName);
        for (MovieRentingInfo movieRenting : movieRentings) {
            if (movieRenting.getRenting_id() == renting_id && movieRenting.getDate_in().isEmpty()) {
                movieRenting.setDate_in(datein);
                movieRenting.setFine_amount(fineAmount);
            }

        }

         
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(fileName))) {
            bw.write("date_out; date_in; client_id; movie_id; rental_id");
            
            for (MovieRentingInfo movieRenting : movieRentings) {
                bw.newLine();
                bw.write(movieRenting.getDate_out() + ";" + movieRenting.getDate_in() + ";"
                        + movieRenting.getClient_id() + ";" + movieRenting.getMovie_id() + ";"
                        + movieRenting.getRenting_id());
            }

            bw.close();

        } catch (IOException ex) {

        }
   }

    @Override
    public int calculateFine(Date in, Date out) {
        int fineAmount = 0;

        long diffInMillies = in.getTime() - out.getTime();
        long diff = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);
        if (diff > 8) {
            int d = (int) diff;
            fineAmount = (d - 8) * 5;
        }

        return fineAmount;
    }

    @Override
    public int rentMovie(String fileName, int movieid, int clientid, String dateout) {
        movieRentings = showMovieRentings(fileName);
        int movieRentingCount = 0;
        int maxMovieRentingId = 0;
        
        for (MovieRentingInfo movieRenting : movieRentings) {
            if (movieRenting.getClient_id() == clientid && movieRenting.getDate_in().isEmpty()) {
                ++movieRentingCount;
            }
            if (movieRenting.getRenting_id() > maxMovieRentingId) {
                maxMovieRentingId = movieRenting.getRenting_id();
            }

        }
        if (movieRentingCount >= 3) {
            return 0;
        }

        if (maxMovieRentingId == 0) {
            maxMovieRentingId = 100;
        }

        
        int id = maxMovieRentingId + 1;
      
        String newMovieRenting = dateout + ";" + ";" +clientid +";"+ movieid +";"+id;
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(fileName, true))) {
            bw.newLine();
            bw.write(newMovieRenting);
            bw.close();
            return id;
        } catch (IOException ex) {

        }

        return 0;

    }

    @Override
    public void registerObserver(IReturnMoviePageGUI observer) {
        movieRentingInfoObservers.add(observer);
    }

    @Override
    public void removeObserver(IReturnMoviePageGUI observer) {
        int i = movieRentingInfoObservers.indexOf(observer);
        if (i >= 0) {
            movieRentingInfoObservers.remove(observer);
        }
    }

    @Override
    public void registerObserver(IRentMoviePageGUI observer) {
        movieRentingInfoObservers.add(observer);
    }

    @Override
    public void removeObserver(IRentMoviePageGUI observer) {
        int i = movieRentingInfoObservers.indexOf(observer);
        if (i >= 0) {
            movieRentingInfoObservers.remove(observer);
        }
    }

    public ArrayList<MovieRentingInfo> getMovieRentings() {
        return movieRentings;
    }

    public void setMovieRentings(ArrayList<MovieRentingInfo> movieRentings) {
        this.movieRentings = movieRentings;
    }

    public int getRenting_id() {
        return renting_id;
    }

    public void setRenting_id(int renting_id) {
        this.renting_id = renting_id;
    }

    public int getClient_id() {
        return client_id;
    }

    public void setClient_id(int client_id) {
        this.client_id = client_id;
    }

    public int getMovie_id() {
        return movie_id;
    }

    public void setMovie_id(int movie_id) {
        this.movie_id = movie_id;
    }

    public String getDate_out() {
        return date_out;
    }

    public void setDate_out(String date_out) {
        this.date_out = date_out;
    }

    public String getDate_in() {
        return date_in;
    }

    public void setDate_in(String date_in) {
        this.date_in = date_in;
    }

    public int getFine_amount() {
        return fine_amount;
    }

    public void setFine_amount(int fine_amount) {
        this.fine_amount = fine_amount;
    }

}
