package Model;

import java.util.ArrayList;
import java.util.Date;
import View.IRentMoviePageGUI;
import View.IReturnMoviePageGUI;
import View.IDisplayRentMovieHistoryPageGUI;

/**
 *
 * @author Nithisha Reddy Boyapati
 */
public interface IMovieRentingInfo {
    
    public void registerObserver(IRentMoviePageGUI observer);

    public void removeObserver(IRentMoviePageGUI observer);
    
    public void registerObserver(IDisplayRentMovieHistoryPageGUI observer);

    public void removeObserver(IDisplayRentMovieHistoryPageGUI observer);

     public ArrayList<MovieRentingInfo> getCurrentRentMovieHistory();

    public void setCurrentRentMovieHistory(ArrayList<MovieRentingInfo> currentRentMovieHistory);

     public ArrayList<MovieRentingInfo> ShowCurrentRentMovieHistory(String fileName, int movie_id);

    public int calculateFine(Date datein, Date dateout);

    public void registerObserver(IReturnMoviePageGUI observer);

    public void removeObserver(IReturnMoviePageGUI observer);

    public void returnMovie(String fileName, int renting_id, String datein, int fineAmount);

    public ArrayList<MovieRentingInfo> getMovieRentings();

    public void setMovieRentings(ArrayList<MovieRentingInfo> movieRentings);

    public ArrayList<MovieRentingInfo> showMovieRentings(String fileName);

    public int rentMovie(String fileName, int movieid, int clientid, String datein);
    
    public int getRenting_id();

    public void setRenting_id(int renting_id);

    public int getClient_id();

    public void setClient_id(int client_id);

    public int getMovie_id();

    public void setMovie_id(int movie_id);

    public String getDate_out();

    public void setDate_out(String date_out);

    public String getDate_in();

    public void setDate_in(String date_in);

    public int getFine_amount();

    public void setFine_amount(int fine_amount);

}
