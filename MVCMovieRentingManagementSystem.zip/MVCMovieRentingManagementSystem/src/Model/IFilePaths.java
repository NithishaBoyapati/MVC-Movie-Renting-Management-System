package Model;

import View.ISelectFilesPageGUI;
import View.IHomePageGUI;

/**
 *
 * @author Nithisha Reddy Boyapati
 */
public interface IFilePaths {

    public void registerObserver(ISelectFilesPageGUI observer);

    public void removeObserver(ISelectFilesPageGUI observer);

    public void registerObserver(IHomePageGUI observer);

    public String getRentingFilePath();

    public void setRentingFilePath(String rentingFilePath);

    public String getMovieFilePath();

    public void setMovieFilePath(String movieFilePath);

    public String getClientFilePath();

    public void setClientFilePath(String clientFilePath);

}
