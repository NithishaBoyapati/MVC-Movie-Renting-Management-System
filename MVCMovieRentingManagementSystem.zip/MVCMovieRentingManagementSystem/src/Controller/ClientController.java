package Controller;

import Model.IClient;
import Model.IFilePaths;
import View.CreateClientPageGUI;
import View.DeleteClientPageGUI;
import View.SearchClientPageGUI;
import View.DisplayClientsPageGUI;

/**
 *
 * @author Nithisha Reddy Boyapati
 */
public class ClientController implements IClientController {

    IFilePaths filePathModel;
    IClient clientModel;
    CreateClientPageGUI createView;
    DeleteClientPageGUI deleteView;
    DisplayClientsPageGUI showClientsView;
    SearchClientPageGUI searchView;

    public ClientController(IClient clientModel, IFilePaths filePathModel, int screen) {
        this.clientModel = clientModel;
        this.filePathModel = filePathModel;
        if (screen == 1) {
            createView = new CreateClientPageGUI(this, clientModel);
            createView.setVisible(true);
        } else if (screen == 2) {
            deleteView = new DeleteClientPageGUI(this, clientModel);
            deleteView.setVisible(true);
        } else if (screen == 3) {
            showClientsView = new DisplayClientsPageGUI(this, clientModel);
            showClientsView.setVisible(true);
        } else if (screen == 4) {
            searchView = new SearchClientPageGUI(this, clientModel);
            searchView.setVisible(true);
        }

    }

    @Override
    public void CreateClient(String firstName, String lastName) {
        int client_id = clientModel.createClient(filePathModel.getClientFilePath(), firstName, lastName);
        clientModel.setClient_id(client_id);
    }

    @Override
    public void DeleteClient(int client_id) {
        clientModel.deleteClient(filePathModel.getClientFilePath(), client_id);
        clientModel.setDeleted("True");
    }

    @Override
    public void ShowAllClients() {
        clientModel.setClients(clientModel.showClients(filePathModel.getClientFilePath()));
    }

    @Override
    public void searchByFirstName(String firstName) {
        clientModel.setResultClients(clientModel.searchByFirstName(filePathModel.getClientFilePath(), firstName));
    }

    @Override
    public void searchByLastName(String lastName) {
        clientModel.setResultClients(clientModel.searchByLastName(filePathModel.getClientFilePath(), lastName));
    }

    @Override
    public void searchByName(String firstName, String lastName) {
        clientModel.setResultClients(clientModel.searchByName(filePathModel.getClientFilePath(), firstName, lastName));
    }

    @Override
    public void BackHome() {
        new HomeController(filePathModel);
    }
}
