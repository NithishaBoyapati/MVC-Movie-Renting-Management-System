package Controller;

/**
 *
 * @author Nithisha Reddy Boyapati
 */
public interface ISelectFilesController {

      public void SetFilePaths(String clientsPath, String moviesPath,String rentingPaths);

    public void GoHome();
}
