package Controller;

import Model.IFilePaths;
import View.SelectFilesPageGUI;

/**
 *
 * @author Nithisha Reddy Boyapati
 */
public class SelectFilesController implements ISelectFilesController {

    IFilePaths model;
    SelectFilesPageGUI view;

    public SelectFilesController(IFilePaths model) {
        this.model = model;
        view = new SelectFilesPageGUI(this, model);
        view.setVisible(true);
    }

    @Override
    public void SetFilePaths(String clientsPath, String moviesPath,String rentingPath) {
        model.setClientFilePath(clientsPath);
        model.setMovieFilePath(moviesPath);
        model.setRentingFilePath(rentingPath);
    }
    
     @Override
    public void GoHome() {
        new HomeController(model);
    }

}
