package Controller;

/**
 *
 * @author Nithisha Reddy Boyapati
 */
public interface IMovieController {

    public void AddMovie(String movieTitle);

    public void BackHome();

    public void ShowAllMovies();

    public void show_CurrentRentedMovies();

}
