package Controller;

import Model.Movie;
import Model.MovieRentingInfo;
import Model.Client;
import Model.IClient;
import Model.IFilePaths;
import View.HomePageGUI;
import Model.IMovie;
import Model.IMovieRentingInfo;

/**
 *
 * @author Nithisha Reddy Boyapati
 */
public class HomeController implements IHomeController {

    IFilePaths filePathModel;
    IClient clientModel;
    IMovie movieModel;
    IMovieRentingInfo movieRentingModel;
    HomePageGUI view;

    public HomeController(IFilePaths filePathModel) {
        this.filePathModel = filePathModel;
        view = new HomePageGUI(this, filePathModel);
        view.setVisible(true);
    }

    @Override
    public void GoCreateClientScreen() {
        clientModel = new Client();
        new ClientController(clientModel, filePathModel, 1);
    }

    @Override
    public void GoDeleteClientScreen() {
        clientModel = new Client();
        new ClientController(clientModel, filePathModel, 2);
    }

    @Override
    public void GoShowAllClientScreen() {
        clientModel = new Client();
        new ClientController(clientModel, filePathModel, 3);
    }

    @Override
    public void GoSearchClientScreen() {
        clientModel = new Client();
        new ClientController(clientModel, filePathModel, 4);
    }

    @Override
    public void GoAddMovieScreen() {
        movieModel = new Movie();
        new MovieController(movieModel, filePathModel, 1);
    }

    @Override
    public void GoRentMovieScreen() {
        movieModel = new Movie();
        clientModel = new Client();
        movieRentingModel = new MovieRentingInfo();
        new MovieRentingController(movieRentingModel, movieModel, clientModel, filePathModel, 1);
    }

    @Override
    public void GoReturnMovieScreen() {
        movieModel = new Movie();
        clientModel = new Client();
        movieRentingModel = new MovieRentingInfo();
        new MovieRentingController(movieRentingModel, movieModel, clientModel, filePathModel, 2);
    }

    @Override
    public void GoShowMoviesScreen() {
        movieModel = new Movie();
        new MovieController(movieModel, filePathModel, 2);
    }

    @Override
    public void GoRentMovieHistoryScreen() {
        movieModel = new Movie();
        clientModel = new Client();
        movieRentingModel = new MovieRentingInfo();
        new MovieRentingController(movieRentingModel, movieModel, clientModel, filePathModel, 3);
    }
}
