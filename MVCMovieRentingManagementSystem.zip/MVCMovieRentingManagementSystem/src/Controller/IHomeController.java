package Controller;

/**
 *
 * @author Nithisha Reddy Boyapati
 */
public interface IHomeController {
    

    public void GoCreateClientScreen();

    public void GoDeleteClientScreen();

    public void GoShowAllClientScreen();

    public void GoSearchClientScreen();

    public void GoAddMovieScreen();

    public void GoRentMovieScreen();

    public void GoReturnMovieScreen();

    public void GoShowMoviesScreen();

    public void GoRentMovieHistoryScreen();
}
