package Controller;

import Model.IFilePaths;
import View.AddMoviePageGUI;
import View.DisplayMoviesPageGUI;
import Model.IMovie;

/**
 *
 * @author Nithisha Reddy Boyapati
 */
public class MovieController implements IMovieController {

    IFilePaths filePathModel;
    IMovie movieModel;
    AddMoviePageGUI addView;
    DisplayMoviesPageGUI showView;

    public MovieController(IMovie movieModel, IFilePaths filePathModel, int screen) {
        this.movieModel = movieModel;
        this.filePathModel = filePathModel;
        if (screen == 1) {
            addView = new AddMoviePageGUI(this, movieModel);
            addView.setVisible(true);
        } else if (screen == 2) {
            showView = new DisplayMoviesPageGUI(this, movieModel);
            showView.setVisible(true);
        }

    }

    @Override
    public void ShowAllMovies() {
        movieModel.setMovies(movieModel.showMovies(filePathModel.getMovieFilePath()));
    }

    @Override
    public void show_CurrentRentedMovies() {
        movieModel.setMovies(movieModel.showCurrentRentedMovies(filePathModel.getMovieFilePath()));
    }

    @Override
    public void AddMovie(String movieTitle) {
        int movie_id = movieModel.addMovie(filePathModel.getMovieFilePath(), movieTitle);
        movieModel.setMovie_id(movie_id);
    }

    @Override
    public void BackHome() {
        new HomeController(filePathModel);
    }
}
