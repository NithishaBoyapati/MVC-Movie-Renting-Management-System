package Controller;

import Model.IClient;
import Model.IFilePaths;
import View.RentMoviePageGUI;
import View.ReturnMoviePageGUI;
import View.DisplayRentMovieHistoryPageGUI;
import java.util.Date;
import Model.IMovie;
import Model.IMovieRentingInfo;

/**
 *
 * @author Nithisha Reddy Boyapati
 */
public class MovieRentingController implements IMovieRentingController {

    IFilePaths filePathModel;
    IMovieRentingInfo model;
    IMovie movieModel;
    IClient clientModel;
    RentMoviePageGUI rentView;
    ReturnMoviePageGUI returnView;
    DisplayRentMovieHistoryPageGUI showView;

    public MovieRentingController(IMovieRentingInfo movieRentingInfo, IMovie movieModel, IClient clientModel, IFilePaths filePathModel, int screen) {
        this.model = movieRentingInfo;
        this.movieModel = movieModel;
        this.clientModel = clientModel;
        this.filePathModel = filePathModel;
        if (screen == 1) {
            rentView = new RentMoviePageGUI(this, movieRentingInfo, movieModel, clientModel);
            rentView.setVisible(true);
        } else if (screen == 2) {
            returnView = new ReturnMoviePageGUI(this, movieRentingInfo, movieModel, clientModel);
            returnView.setVisible(true);
        } else if (screen == 3) {
            showView = new DisplayRentMovieHistoryPageGUI(this, movieRentingInfo, movieModel, clientModel);
            showView.setVisible(true);
        }
    }

    @Override
    public void ShowAllRentingInfo() {
        model.setMovieRentings(model.showMovieRentings(filePathModel.getRentingFilePath()));
    }

    @Override
    public void ShowCurrentRentMovieHistory(int movie_id) {
        model.setCurrentRentMovieHistory(model.ShowCurrentRentMovieHistory(filePathModel.getRentingFilePath(), movie_id));

    }

    @Override
    public void rentMovie(int movieid, int clientid, String dateout) {
        model.setRenting_id(model.rentMovie(filePathModel.getRentingFilePath(), movieid, clientid, dateout));
    }

    @Override
    public void returnMovie(int renting_id, String datein, int fineAmount) {
        model.returnMovie(filePathModel.getRentingFilePath(), renting_id, datein, fineAmount);
        model.setDate_in(datein);
    }

    @Override
    public void returnMovieUpdate(int movie_id) {
        movieModel.rentMovieUpdate(filePathModel.getMovieFilePath(), movie_id, "False");
        movieModel.setRent("False");

    }

    @Override
    public void RentMovieUpdate(int movie_id) {
        movieModel.rentMovieUpdate(filePathModel.getMovieFilePath(), movie_id, "True");
        movieModel.setRent("True");

    }

    @Override
    public void calculateFine(Date datein, Date dateout) {
        model.setFine_amount(model.calculateFine(datein, dateout));

    }

    @Override
    public void ShowAllMovies() {
        movieModel.setMovies(movieModel.showMovies(filePathModel.getMovieFilePath()));
    }

    @Override
    public void ShowAllClients() {
        clientModel.setClients(clientModel.showClients(filePathModel.getClientFilePath()));
    }

    @Override
    public void BackHome() {
        new HomeController(filePathModel);
    }

}
