package Controller;

import java.util.Date;

/**
 *
 * @author Nithisha Reddy Boyapati
 */
public interface IMovieRentingController {
     public void ShowCurrentRentMovieHistory(int movie_id);

    public void calculateFine(Date datein, Date dateout);

    public void returnMovie(int renting_id, String datein, int fineAmount);

    public void returnMovieUpdate(int movie_id);

    public void ShowAllMovies();

    public void ShowAllClients();

    public void BackHome();

    public void rentMovie(int movieid, int clientid, String datein);

    public void RentMovieUpdate(int movie_id);

    public void ShowAllRentingInfo();

}
