package Controller;

/**
 *
 * @author Nithisha Reddy Boyapati
 */
public interface IClientController {

    public void CreateClient(String firstName, String lastName);

    public void DeleteClient(int client_id);

    public void ShowAllClients();

    public void BackHome();

    public void searchByFirstName( String firstName);

    public void searchByLastName(String lastName);

    public void searchByName(String firstName, String lastName);

}
