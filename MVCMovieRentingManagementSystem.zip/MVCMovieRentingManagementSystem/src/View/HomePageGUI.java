package View;

import Controller.IHomeController;
import Model.IFilePaths;

/**
 *
 * @author Nithisha Reddy Boyapati
 */
public class HomePageGUI extends javax.swing.JFrame implements IHomePageGUI {

    IHomeController controller;
    IFilePaths model;

    public HomePageGUI() {
        initComponents();
    }

    public HomePageGUI(IHomeController controller, IFilePaths model) {
        initComponents();
       
        setSize(2000, 2000);
        setResizable(false); 
        setLocationRelativeTo(null); 
        
        this.model = model;
        this.controller = controller;
        model.registerObserver((IHomePageGUI) this);
        btnRentMovieHistory.setText("<html><br> MOVIE  RENT HISTORY");


    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlHome = new javax.swing.JPanel();
        btnShowClients = new javax.swing.JButton();
        btnCreateClient = new javax.swing.JButton();
        btnDeleteClient = new javax.swing.JButton();
        btnSearchClient = new javax.swing.JButton();
        btnRentMovie = new javax.swing.JButton();
        btnShowMovies = new javax.swing.JButton();
        btnAddMovie = new javax.swing.JButton();
        btnRentMovieHistory = new javax.swing.JButton();
        btnReturnMovie = new javax.swing.JButton();
        lblWelcome = new javax.swing.JLabel();
        btnBack = new javax.swing.JButton();
        Background = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        pnlHome.setBackground(new java.awt.Color(15, 22, 38));
        pnlHome.setPreferredSize(new java.awt.Dimension(2000, 2000));
        pnlHome.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnShowClients.setBackground(new java.awt.Color(0, 255, 255));
        btnShowClients.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        btnShowClients.setText("DISPLAY CLIENTS");
        btnShowClients.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnShowClientsActionPerformed(evt);
            }
        });
        pnlHome.add(btnShowClients, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 530, 650, 50));

        btnCreateClient.setBackground(new java.awt.Color(0, 255, 255));
        btnCreateClient.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        btnCreateClient.setText("CREATING CLIENT");
        btnCreateClient.setMaximumSize(new java.awt.Dimension(100, 25));
        btnCreateClient.setMinimumSize(new java.awt.Dimension(100, 25));
        btnCreateClient.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCreateClientActionPerformed(evt);
            }
        });
        pnlHome.add(btnCreateClient, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 50, 650, 60));

        btnDeleteClient.setBackground(new java.awt.Color(0, 255, 255));
        btnDeleteClient.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        btnDeleteClient.setText("DELETING CLIENT");
        btnDeleteClient.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteClientActionPerformed(evt);
            }
        });
        pnlHome.add(btnDeleteClient, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 340, 650, 50));

        btnSearchClient.setBackground(new java.awt.Color(0, 255, 255));
        btnSearchClient.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        btnSearchClient.setText("SEARCHING CLIENT");
        btnSearchClient.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchClientActionPerformed(evt);
            }
        });
        pnlHome.add(btnSearchClient, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 630, 650, 50));

        btnRentMovie.setBackground(new java.awt.Color(0, 255, 255));
        btnRentMovie.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        btnRentMovie.setText("RENTING MOVIE");
        btnRentMovie.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRentMovieActionPerformed(evt);
            }
        });
        pnlHome.add(btnRentMovie, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 250, 650, 50));

        btnShowMovies.setBackground(new java.awt.Color(0, 255, 255));
        btnShowMovies.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        btnShowMovies.setText("DISPLAY MOVIES");
        btnShowMovies.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnShowMoviesActionPerformed(evt);
            }
        });
        pnlHome.add(btnShowMovies, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 440, 650, 50));

        btnAddMovie.setBackground(new java.awt.Color(0, 255, 255));
        btnAddMovie.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        btnAddMovie.setText("ADDING MOVIE");
        btnAddMovie.setMaximumSize(new java.awt.Dimension(100, 25));
        btnAddMovie.setMinimumSize(new java.awt.Dimension(100, 25));
        btnAddMovie.setPreferredSize(new java.awt.Dimension(100, 25));
        btnAddMovie.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddMovieActionPerformed(evt);
            }
        });
        pnlHome.add(btnAddMovie, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 150, 650, 50));

        btnRentMovieHistory.setBackground(new java.awt.Color(0, 255, 255));
        btnRentMovieHistory.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        btnRentMovieHistory.setText("RENT MOVIE HISTORY");
        btnRentMovieHistory.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        btnRentMovieHistory.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        btnRentMovieHistory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRentMovieHistoryActionPerformed(evt);
            }
        });
        pnlHome.add(btnRentMovieHistory, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 830, 650, 70));

        btnReturnMovie.setBackground(new java.awt.Color(0, 255, 255));
        btnReturnMovie.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        btnReturnMovie.setText("RETURNING MOVIE");
        btnReturnMovie.setAlignmentX(0.5F);
        btnReturnMovie.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnReturnMovie.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReturnMovieActionPerformed(evt);
            }
        });
        pnlHome.add(btnReturnMovie, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 730, 650, 50));

        lblWelcome.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        lblWelcome.setForeground(new java.awt.Color(0, 255, 255));
        lblWelcome.setText("WELCOME");
        pnlHome.add(lblWelcome, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 50, 120, 50));

        btnBack.setBackground(new java.awt.Color(0, 255, 255));
        btnBack.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        btnBack.setText("EXIT");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });
        pnlHome.add(btnBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 950, 100, -1));

        Background.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/4000x4000.jpg"))); // NOI18N
        pnlHome.add(Background, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 2000, 2000));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlHome, javax.swing.GroupLayout.PREFERRED_SIZE, 2000, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlHome, javax.swing.GroupLayout.PREFERRED_SIZE, 2000, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnDeleteClientActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteClientActionPerformed
        this.setVisible(false);
        controller.GoDeleteClientScreen();
    }//GEN-LAST:event_btnDeleteClientActionPerformed

    private void btnCreateClientActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCreateClientActionPerformed

        this.setVisible(false);
        controller.GoCreateClientScreen();
    }//GEN-LAST:event_btnCreateClientActionPerformed

    private void btnShowClientsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnShowClientsActionPerformed
        this.setVisible(false);
        controller.GoShowAllClientScreen();
    }//GEN-LAST:event_btnShowClientsActionPerformed

    private void btnSearchClientActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchClientActionPerformed
        this.setVisible(false);
        controller.GoSearchClientScreen();
    }//GEN-LAST:event_btnSearchClientActionPerformed

    private void btnAddMovieActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddMovieActionPerformed
        this.setVisible(false);
        controller.GoAddMovieScreen();
    }//GEN-LAST:event_btnAddMovieActionPerformed

    private void btnRentMovieActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRentMovieActionPerformed
         this.setVisible(false);
        controller.GoRentMovieScreen();
    }//GEN-LAST:event_btnRentMovieActionPerformed

    private void btnReturnMovieActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReturnMovieActionPerformed
        this.setVisible(false);
        controller.GoReturnMovieScreen();
    }//GEN-LAST:event_btnReturnMovieActionPerformed

    private void btnRentMovieHistoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRentMovieHistoryActionPerformed
         this.setVisible(false);
        controller.GoRentMovieHistoryScreen();
    }//GEN-LAST:event_btnRentMovieHistoryActionPerformed

    private void btnShowMoviesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnShowMoviesActionPerformed
       this.setVisible(false);
        controller.GoShowMoviesScreen();
    }//GEN-LAST:event_btnShowMoviesActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
      System.exit(0);  
    }//GEN-LAST:event_btnBackActionPerformed

    
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new HomePageGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Background;
    private javax.swing.JButton btnAddMovie;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnCreateClient;
    private javax.swing.JButton btnDeleteClient;
    private javax.swing.JButton btnRentMovie;
    private javax.swing.JButton btnRentMovieHistory;
    private javax.swing.JButton btnReturnMovie;
    private javax.swing.JButton btnSearchClient;
    private javax.swing.JButton btnShowClients;
    private javax.swing.JButton btnShowMovies;
    private javax.swing.JLabel lblWelcome;
    private javax.swing.JPanel pnlHome;
    // End of variables declaration//GEN-END:variables
}
