package View;

/**
 *
 * @author Nithisha Reddy Boyapati
 */
public interface ISelectFilesPageGUI {

    public void SetFilePaths(String clientsPath, String moviesPath, String rentingPath);
}
