
package View;

/**
 *
 * @author Nithisha Reddy Boyapati
 */
public interface IHomePageGUI {
    
}
