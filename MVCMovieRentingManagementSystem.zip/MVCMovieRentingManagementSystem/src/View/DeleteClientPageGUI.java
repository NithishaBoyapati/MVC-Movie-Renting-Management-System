package View;

import Controller.IClientController;
import Model.Client;
import Model.IClient;
import java.awt.Color;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

/**
 *
 * @author Nithisha Reddy Boyapati
 */
public class DeleteClientPageGUI extends javax.swing.JFrame implements IDeleteClientPageGUI {

    IClientController controller;
    IClient model;

    public DeleteClientPageGUI() {
        initComponents();
    }

    public DeleteClientPageGUI(IClientController controller, IClient model) {
        initComponents();
        
        setSize(2000, 2000);
        setResizable(false); 
        setLocationRelativeTo(null);
       
        this.model = model;
        this.controller = controller;

        jTable_Clients.setFillsViewportHeight(true);
        jTable_Clients.getTableHeader().setBackground(new Color(0,255,255));
        jTable_Clients.getTableHeader().setOpaque(false);
       jTable_Clients.setGridColor(new Color(0, 255, 255));
       // model.registerObserver((IDeleteClientPageGUI) this);
        jTable_Clients.setShowHorizontalLines(true);
        show_Clients();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        pnlDeleteClient = new javax.swing.JPanel();
        btnBack = new javax.swing.JButton();
        lblHeading = new javax.swing.JLabel();
        scrollDeleteClient = new javax.swing.JScrollPane();
        scrollDeleteClient1 = new javax.swing.JScrollPane();
        jTable_Clients = new javax.swing.JTable();
        btnDelete = new javax.swing.JButton();
        lblNote = new javax.swing.JLabel();
        Background = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(2000, 2000));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        pnlDeleteClient.setBackground(new java.awt.Color(204, 255, 255));
        pnlDeleteClient.setPreferredSize(new java.awt.Dimension(2000, 2000));
        pnlDeleteClient.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnBack.setBackground(new java.awt.Color(0, 255, 255));
        btnBack.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        btnBack.setText("BACK");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });
        pnlDeleteClient.add(btnBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(1450, 540, -1, -1));

        lblHeading.setBackground(new java.awt.Color(204, 204, 204));
        lblHeading.setFont(new java.awt.Font("Calibri", 1, 36)); // NOI18N
        lblHeading.setForeground(new java.awt.Color(0, 255, 255));
        lblHeading.setText("DELETE CLIENT");
        pnlDeleteClient.add(lblHeading, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 60, 270, -1));

        scrollDeleteClient.setBackground(new java.awt.Color(204, 255, 255));
        scrollDeleteClient.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        scrollDeleteClient1.setBackground(new java.awt.Color(204, 255, 255));
        scrollDeleteClient1.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        jTable_Clients.setBackground(new java.awt.Color(204, 255, 255));
        jTable_Clients.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Name", "Client ID", "DeletedStatus"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable_Clients.setGridColor(new java.awt.Color(204, 255, 255));
        jTable_Clients.setSelectionBackground(new java.awt.Color(0, 255, 255));
        jTable_Clients.setSelectionForeground(new java.awt.Color(0, 0, 0));
        jTable_Clients.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable_ClientsMouseClicked(evt);
            }
        });
        scrollDeleteClient1.setViewportView(jTable_Clients);
        if (jTable_Clients.getColumnModel().getColumnCount() > 0) {
            jTable_Clients.getColumnModel().getColumn(0).setPreferredWidth(10);
            jTable_Clients.getColumnModel().getColumn(1).setPreferredWidth(50);
            jTable_Clients.getColumnModel().getColumn(2).setPreferredWidth(50);
        }

        scrollDeleteClient.setViewportView(scrollDeleteClient1);

        pnlDeleteClient.add(scrollDeleteClient, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 340, 900, 400));

        btnDelete.setBackground(new java.awt.Color(0, 255, 255));
        btnDelete.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        btnDelete.setText("DELETE");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });
        pnlDeleteClient.add(btnDelete, new org.netbeans.lib.awtextra.AbsoluteConstraints(1440, 460, -1, -1));

        lblNote.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        lblNote.setForeground(new java.awt.Color(0, 255, 255));
        lblNote.setText("*SYSTEM WILL ONLY UPDATE DELETE FLAG AS CLIENT WILL NOT BE COMPLETELY DELETED BY THE SYSTEM");
        pnlDeleteClient.add(lblNote, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 180, -1, -1));

        Background.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/4000x4000.jpg"))); // NOI18N
        pnlDeleteClient.add(Background, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 2000, 2000));
        pnlDeleteClient.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable2);

        pnlDeleteClient.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        getContentPane().add(pnlDeleteClient, new org.netbeans.lib.awtextra.AbsoluteConstraints(-8, -10, 2000, 2000));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed

        if (deleted_flag == "True") {
            JOptionPane.showMessageDialog(null, "Client is already deleted from the system");
            return;
        }

        int result = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this client",
                "alert", JOptionPane.OK_CANCEL_OPTION);
        if (result == 0) {
            deleteClient(client_id);
            if (model.getDeleted() == "True") {
                JOptionPane.showMessageDialog(null, "Client got deleted successfully");
                show_Clients();
            }
        }
    }//GEN-LAST:event_btnDeleteActionPerformed
    int client_id;
    String deleted_flag;

    @Override
    public void deleteClient(int client_id) {
        controller.DeleteClient(client_id);
    }

    @Override
    public void show_Clients() {
        
        controller.ShowAllClients();
        
        ArrayList<Client> clients = model.getClients();

        DefaultTableModel model = (DefaultTableModel) jTable_Clients.getModel();
        model.setRowCount(0);
        Object[] row = new Object[3];
        for (int i = 0; i < clients.size(); i++) {
            row[0] = clients.get(i).getName();
            row[1] = clients.get(i).getClient_id();
            row[2] = clients.get(i).getDeleted().equalsIgnoreCase("False") ? "Active" : "InActive";
            model.addRow(row);

        }

    }


    private void jTable_ClientsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable_ClientsMouseClicked
        int i = jTable_Clients.getSelectedRow();
        TableModel tableModel = jTable_Clients.getModel();
        client_id = (Integer.parseInt(tableModel.getValueAt(i, 1).toString()));
        deleted_flag = tableModel.getValueAt(i, 2).toString().equals("Active")?"False":"True";

    }//GEN-LAST:event_jTable_ClientsMouseClicked

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        this.setVisible(false);
        this.dispose();
        controller.BackHome();
    }//GEN-LAST:event_btnBackActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DeleteClientPageGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Background;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnDelete;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable_Clients;
    private javax.swing.JLabel lblHeading;
    private javax.swing.JLabel lblNote;
    private javax.swing.JPanel pnlDeleteClient;
    private javax.swing.JScrollPane scrollDeleteClient;
    private javax.swing.JScrollPane scrollDeleteClient1;
    // End of variables declaration//GEN-END:variables
}
