package View;

import Controller.IClientController;
import Model.Client;
import Model.IClient;
import java.awt.Color;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Nithisha Reddy Boyapati
 */
public class SearchClientPageGUI extends javax.swing.JFrame implements ISearchClientPageGUI {

    IClientController controller;
    IClient model;

    public SearchClientPageGUI() {
        initComponents();
    }

    public SearchClientPageGUI(IClientController controller, IClient model) {
        initComponents();
        
        setSize(2000, 2000);
        setResizable(false); 
        setLocationRelativeTo(null);
        
        this.model = model;
        this.controller = controller;

        model.registerObserver((ISearchClientPageGUI) this);
 jTable_Clients.setFillsViewportHeight(true);
        jTable_Clients.getTableHeader().setBackground(new Color(0,255,255));
        jTable_Clients.getTableHeader().setOpaque(false);
        jTable_Clients.setGridColor(new Color(0, 255, 255));


    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlSearchClient = new javax.swing.JPanel();
        lblHeading = new javax.swing.JLabel();
        btnBack = new javax.swing.JButton();
        btnSearch = new javax.swing.JButton();
        lblFirstName = new javax.swing.JLabel();
        lblLastName = new javax.swing.JLabel();
        lblNote = new javax.swing.JLabel();
        txtFirstName = new javax.swing.JTextField();
        txtLastName = new javax.swing.JTextField();
        scrollSearchClient = new javax.swing.JScrollPane();
        scrollSearchClient1 = new javax.swing.JScrollPane();
        jTable_Clients = new javax.swing.JTable();
        Background = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(2000, 2000));

        pnlSearchClient.setPreferredSize(new java.awt.Dimension(2000, 2000));
        pnlSearchClient.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblHeading.setFont(new java.awt.Font("Calibri", 1, 36)); // NOI18N
        lblHeading.setForeground(new java.awt.Color(0, 255, 255));
        lblHeading.setText("SEARCH CLIENT");
        pnlSearchClient.add(lblHeading, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 60, 270, -1));

        btnBack.setBackground(new java.awt.Color(0, 255, 255));
        btnBack.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        btnBack.setText("BACK");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });
        pnlSearchClient.add(btnBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(1470, 670, 110, -1));

        btnSearch.setBackground(new java.awt.Color(0, 255, 255));
        btnSearch.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        btnSearch.setText("SEARCH ");
        btnSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchActionPerformed(evt);
            }
        });
        pnlSearchClient.add(btnSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(1170, 420, -1, -1));

        lblFirstName.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        lblFirstName.setForeground(new java.awt.Color(0, 255, 255));
        lblFirstName.setText("FIRST NAME");
        pnlSearchClient.add(lblFirstName, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 370, -1, 30));

        lblLastName.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        lblLastName.setForeground(new java.awt.Color(0, 255, 255));
        lblLastName.setText("LAST NAME");
        pnlSearchClient.add(lblLastName, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 370, 140, -1));

        lblNote.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        lblNote.setForeground(new java.awt.Color(0, 255, 255));
        lblNote.setText("*SEARCHING FOR CLIENTS BY PROVIDING THEIR NAMES.");
        pnlSearchClient.add(lblNote, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 190, 610, 27));

        txtFirstName.setBackground(new java.awt.Color(204, 255, 255));
        txtFirstName.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        pnlSearchClient.add(txtFirstName, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 420, 320, -1));

        txtLastName.setBackground(new java.awt.Color(204, 255, 255));
        txtLastName.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        txtLastName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtLastNameActionPerformed(evt);
            }
        });
        pnlSearchClient.add(txtLastName, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 420, 310, -1));

        scrollSearchClient.setBackground(new java.awt.Color(204, 255, 255));

        scrollSearchClient1.setBackground(new java.awt.Color(204, 255, 255));
        scrollSearchClient1.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        jTable_Clients.setBackground(new java.awt.Color(204, 255, 255));
        jTable_Clients.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Name", "Client ID", "Deleted"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable_Clients.setGridColor(new java.awt.Color(204, 255, 255));
        jTable_Clients.setSelectionBackground(new java.awt.Color(0, 255, 255));
        jTable_Clients.setSelectionForeground(new java.awt.Color(0, 0, 0));
        scrollSearchClient1.setViewportView(jTable_Clients);

        scrollSearchClient.setViewportView(scrollSearchClient1);

        pnlSearchClient.add(scrollSearchClient, new org.netbeans.lib.awtextra.AbsoluteConstraints(294, 490, 980, 400));

        Background.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/4000x4000.jpg"))); // NOI18N
        pnlSearchClient.add(Background, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 2000, 2000));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnlSearchClient, javax.swing.GroupLayout.PREFERRED_SIZE, 2000, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlSearchClient, javax.swing.GroupLayout.PREFERRED_SIZE, 2000, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed

        if (txtFirstName.getText().trim().isEmpty() && txtLastName.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please provide FirstName or LastName");
            return;
        }
        searchClient(txtFirstName.getText().trim(), txtLastName.getText().trim());
        show_Clients();
    }//GEN-LAST:event_btnSearchActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        this.setVisible(false);
        this.dispose();
        controller.BackHome();
    }//GEN-LAST:event_btnBackActionPerformed

    private void txtLastNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtLastNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtLastNameActionPerformed

    @Override
    public void searchClient(String firstName, String lastName) {
        if (!(firstName.isEmpty()) && !(lastName.isEmpty())) {
            controller.searchByName(firstName, lastName);
        } else if (!(firstName.isEmpty()) && lastName.isEmpty()) {
            controller.searchByFirstName(firstName);
        } else {
            controller.searchByLastName(lastName);
        }

    }

    @Override
    public void show_Clients() {
        
        controller.ShowAllClients();
        
        ArrayList<Client> clients = model.getResultClients();

        DefaultTableModel model = (DefaultTableModel) jTable_Clients.getModel();
        model.setRowCount(0);
        Object[] row = new Object[3];
        for (int i = 0; i < clients.size(); i++) {
            row[0] = clients.get(i).getName();
            row[1] = clients.get(i).getClient_id();
            row[2] = clients.get(i).getDeleted().equalsIgnoreCase("False") ? "Active" : "InActive";
            model.addRow(row);

        }
        if (clients.size() <= 0) {
            JOptionPane.showMessageDialog(null, "No Results found!!");
            return;
        }
    }

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SearchClientPageGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Background;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnSearch;
    private javax.swing.JTable jTable_Clients;
    private javax.swing.JLabel lblFirstName;
    private javax.swing.JLabel lblHeading;
    private javax.swing.JLabel lblLastName;
    private javax.swing.JLabel lblNote;
    private javax.swing.JPanel pnlSearchClient;
    private javax.swing.JScrollPane scrollSearchClient;
    private javax.swing.JScrollPane scrollSearchClient1;
    private javax.swing.JTextField txtFirstName;
    private javax.swing.JTextField txtLastName;
    // End of variables declaration//GEN-END:variables
}
