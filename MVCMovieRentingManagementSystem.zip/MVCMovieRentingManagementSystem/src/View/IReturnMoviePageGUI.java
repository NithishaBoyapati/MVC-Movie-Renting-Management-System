package View;

/**
 *
 * @author Nithisha Reddy Boyapati
 */
public interface IReturnMoviePageGUI {

    public void setMovieInfo();

    public void setRentingInfo();

    public void setClientInfo();

    public void setMoviesComboBox();

    public void clearFields();

  public void returnMovie(int renting_id, int movieid, String date_in, int fineAmount);

    public void calculateFine();
}
