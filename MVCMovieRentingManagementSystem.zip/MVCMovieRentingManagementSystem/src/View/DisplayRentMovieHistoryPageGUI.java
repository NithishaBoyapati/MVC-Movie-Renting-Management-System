package View;

import Model.Movie;
import Model.MovieRentingInfo;
import Model.Client;
import Model.IClient;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import javax.swing.DefaultComboBoxModel;
import javax.swing.table.DefaultTableModel;
import Model.IMovie;
import Model.IMovieRentingInfo;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import Controller.IMovieRentingController;

/**
 *
 * @author Nithisha Reddy Boyapati
 */
public class DisplayRentMovieHistoryPageGUI extends javax.swing.JFrame implements IDisplayRentMovieHistoryPageGUI {

    IMovieRentingController controller;
    IMovieRentingInfo model;
    IMovie movieModel;
    IClient clientModel;

    public DisplayRentMovieHistoryPageGUI() {
        initComponents();
    }

    public DisplayRentMovieHistoryPageGUI(IMovieRentingController controller, IMovieRentingInfo model, IMovie movieModel, IClient clientModel) {
        initComponents();
        
        setSize(2000, 2000);
        setResizable(false); 
        setLocationRelativeTo(null); 
      
        this.model = model;
        this.controller = controller;
        this.movieModel = movieModel;
        this.clientModel = clientModel;
        model.registerObserver((IDisplayRentMovieHistoryPageGUI) this);
        setMoviesComboBox();
        setMovieID(cmbMovies.getSelectedItem().toString());

        showRentMovieHistory();
        
         jTable_Movies.setFillsViewportHeight(true);
        jTable_Movies.getTableHeader().setBackground(new Color(0,255,255));
        jTable_Movies.getTableHeader().setOpaque(false);
        jTable_Movies.setGridColor(new Color(0, 255, 255));

    }

    int movie_id = 0;

    @Override
    public void setMoviesComboBox() {
        controller.ShowAllMovies();
        ArrayList<Movie> movies = movieModel.getMovies();
        ArrayList<String> movieNames = new ArrayList<String>();
        int movieCount = 1;
        for (Movie movie : movies) {
            if (movieCount == 1) {
                movie_id = movie.getMovie_id();
            }
            movieNames.add(movie.getMovie_title());
            movieCount++;
        }

        cmbMovies.setModel(new DefaultComboBoxModel(movieNames.toArray()));

    }

    @Override
    public void showRentMovieHistory() {
        
        if (movie_id != 0) {
            controller.ShowCurrentRentMovieHistory(movie_id);
            
            ArrayList<MovieRentingInfo> movieRentings = model.getCurrentRentMovieHistory();
            Collections.sort(movieRentings);
            DefaultTableModel model = (DefaultTableModel) jTable_Movies.getModel();
            model.setRowCount(0);
            Object[] row = new Object[6];
            for (int i = 0; i < movieRentings.size(); i++) {
                row[0] = movieRentings.get(i).getRenting_id();
                row[1] = setClientName(movieRentings.get(i).getClient_id());
                row[2] = setMovieName(movieRentings.get(i).getMovie_id());
                row[3] = movieRentings.get(i).getDate_out();
                row[4] = movieRentings.get(i).getDate_in();
                try {
                    row[5] =calculateFine(movieRentings.get(i).getDate_in(),movieRentings.get(i).getDate_out());
                } catch (ParseException ex) {
                    Logger.getLogger(DisplayRentMovieHistoryPageGUI.class.getName()).log(Level.SEVERE, null, ex);
                }
                model.addRow(row);
            }
        }
    }
    
    public int calculateFine(String in, String out) throws ParseException {
        
        int fineAmount = 0;
        if(in !=null && !in.equalsIgnoreCase("")) {
        Date datein = new SimpleDateFormat("MM/dd/yyyy").parse(in);
        Date dateout = new SimpleDateFormat("MM/dd/yyyy").parse(out);

        long diffInMillies = datein.getTime() - dateout.getTime();
        long diff = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);
        if (diff > 8) {
            int d = (int) diff;
            fineAmount = (d - 8) * 5;
        }
        }

        return fineAmount;
    }

    @Override
    public String setMovieName(int movie_id) {
        controller.ShowAllMovies();
        ArrayList<Movie> movies = movieModel.getMovies();

        for (Movie movie : movies) {
            if (movie.getMovie_id() == movie_id) {
                return movie.getMovie_title();
            }

        }
        return null;
    }

    @Override
    public void setMovieID(String movie_title) {

        controller.ShowAllMovies();
        ArrayList<Movie> movies = movieModel.getMovies();

        for (Movie movie : movies) {
            if (movie.getMovie_title().equals(movie_title)) {
                movie_id = movie.getMovie_id();
            }

        }
    }

    @Override
    public String setClientName(int client_id) {
        controller.ShowAllClients();
        ArrayList<Client> clients = clientModel.getClients();

        for (Client client : clients) {
            if (client.getClient_id() == client_id) {
                return client.getName();
            }

        }
        return null;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlShowRentMovieHistory = new javax.swing.JPanel();
        lblHeading = new javax.swing.JLabel();
        btnBack = new javax.swing.JButton();
        lblMovies = new javax.swing.JLabel();
        cmbMovies = new javax.swing.JComboBox<>();
        scrollJtableRentingInfo = new javax.swing.JScrollPane();
        scrollJtableRentingInfo1 = new javax.swing.JScrollPane();
        jTable_Movies = new javax.swing.JTable();
        Background = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(2000, 2000));

        pnlShowRentMovieHistory.setPreferredSize(new java.awt.Dimension(2000, 2000));
        pnlShowRentMovieHistory.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblHeading.setFont(new java.awt.Font("Calibri", 1, 36)); // NOI18N
        lblHeading.setForeground(new java.awt.Color(0, 255, 255));
        lblHeading.setText("MOVIE RENT HISTORY");
        pnlShowRentMovieHistory.add(lblHeading, new org.netbeans.lib.awtextra.AbsoluteConstraints(900, 50, -1, -1));

        btnBack.setBackground(new java.awt.Color(0, 255, 255));
        btnBack.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        btnBack.setText("BACK");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });
        pnlShowRentMovieHistory.add(btnBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(1040, 790, 110, 50));

        lblMovies.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        lblMovies.setForeground(new java.awt.Color(0, 255, 255));
        lblMovies.setText("MOVIE");
        pnlShowRentMovieHistory.add(lblMovies, new org.netbeans.lib.awtextra.AbsoluteConstraints(1340, 430, 90, -1));

        cmbMovies.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        cmbMovies.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbMoviesActionPerformed(evt);
            }
        });
        pnlShowRentMovieHistory.add(cmbMovies, new org.netbeans.lib.awtextra.AbsoluteConstraints(1270, 480, 220, -1));

        scrollJtableRentingInfo.setBackground(new java.awt.Color(204, 255, 255));

        scrollJtableRentingInfo1.setBackground(new java.awt.Color(204, 255, 255));

        jTable_Movies.setBackground(new java.awt.Color(204, 255, 255));
        jTable_Movies.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "RentingId", "ClientName", "MovieTitle", "DateOut", "DateIn", "FineAmount"
            }
        ));
        jTable_Movies.setGridColor(new java.awt.Color(204, 255, 255));
        jTable_Movies.setSelectionBackground(new java.awt.Color(0, 255, 255));
        jTable_Movies.setSelectionForeground(new java.awt.Color(0, 0, 0));
        scrollJtableRentingInfo1.setViewportView(jTable_Movies);
        if (jTable_Movies.getColumnModel().getColumnCount() > 0) {
            jTable_Movies.getColumnModel().getColumn(0).setPreferredWidth(20);
            jTable_Movies.getColumnModel().getColumn(3).setPreferredWidth(20);
            jTable_Movies.getColumnModel().getColumn(4).setPreferredWidth(20);
            jTable_Movies.getColumnModel().getColumn(5).setPreferredWidth(20);
        }

        scrollJtableRentingInfo.setViewportView(scrollJtableRentingInfo1);

        pnlShowRentMovieHistory.add(scrollJtableRentingInfo, new org.netbeans.lib.awtextra.AbsoluteConstraints(149, 319, 900, 380));

        Background.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/4000x4000.jpg"))); // NOI18N
        Background.setText("jLabel3");
        pnlShowRentMovieHistory.add(Background, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 2000, 2000));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlShowRentMovieHistory, javax.swing.GroupLayout.PREFERRED_SIZE, 2000, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlShowRentMovieHistory, javax.swing.GroupLayout.PREFERRED_SIZE, 2000, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cmbMoviesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbMoviesActionPerformed
        setMovieID(cmbMovies.getSelectedItem().toString());
        showRentMovieHistory();
    }//GEN-LAST:event_cmbMoviesActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        this.setVisible(false);
        this.dispose();
        controller.BackHome();
    }//GEN-LAST:event_btnBackActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DisplayRentMovieHistoryPageGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Background;
    private javax.swing.JButton btnBack;
    private javax.swing.JComboBox<String> cmbMovies;
    private javax.swing.JTable jTable_Movies;
    private javax.swing.JLabel lblHeading;
    private javax.swing.JLabel lblMovies;
    private javax.swing.JPanel pnlShowRentMovieHistory;
    private javax.swing.JScrollPane scrollJtableRentingInfo;
    private javax.swing.JScrollPane scrollJtableRentingInfo1;
    // End of variables declaration//GEN-END:variables
}
