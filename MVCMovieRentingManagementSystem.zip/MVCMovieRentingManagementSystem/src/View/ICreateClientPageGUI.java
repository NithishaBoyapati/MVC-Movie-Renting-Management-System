package View;

/**
 *
 * @author Nithisha Reddy Boyapati
 */
public interface ICreateClientPageGUI {

    public void createClient(String firstName, String lastName);

    public void clearFields();
}
