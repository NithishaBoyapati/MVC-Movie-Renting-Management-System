package View;

/**
 *
 * @author Nithisha Reddy Boyapati
 */
public interface IDisplayRentMovieHistoryPageGUI {

    public void setMoviesComboBox();

    public void showRentMovieHistory();

    public String setMovieName(int movie_id);

    public void setMovieID(String movie_title);

    public String setClientName(int client_id);

}
