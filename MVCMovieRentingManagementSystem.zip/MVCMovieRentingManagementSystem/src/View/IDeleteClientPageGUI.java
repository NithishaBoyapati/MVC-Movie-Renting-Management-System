package View;

/**
 *
 * @author Nithisha Reddy Boyapati
 */
public interface IDeleteClientPageGUI {

    public void show_Clients();

    public void deleteClient(int client_id);
}
