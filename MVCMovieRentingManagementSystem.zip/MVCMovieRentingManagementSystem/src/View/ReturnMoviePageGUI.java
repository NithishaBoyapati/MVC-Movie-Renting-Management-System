package View;

import Model.Movie;
import Model.MovieRentingInfo;
import Model.Client;
import Model.IClient;
import java.text.*;
import java.util.*;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import Model.IMovie;
import Model.IMovieRentingInfo;
import Controller.IMovieRentingController;

/**
 *
 * @author Nithisha Reddy Boyapati
 */
public class ReturnMoviePageGUI extends javax.swing.JFrame implements IReturnMoviePageGUI {

    IMovieRentingController controller;
    IMovieRentingInfo model;
    IMovie movieModel;
    IClient clientModel;

    public ReturnMoviePageGUI() {
        initComponents();
    }

    public ReturnMoviePageGUI(IMovieRentingController controller, IMovieRentingInfo model, IMovie movieModel, IClient clientModel) {
        initComponents();
      
        setSize(2000, 2000);
        setResizable(false); 
        setLocationRelativeTo(null);
        
        this.model = model;
        this.controller = controller;
        this.movieModel = movieModel;
        this.clientModel = clientModel;
        date_in.setDate(new Date());
        model.registerObserver((IReturnMoviePageGUI) this);

        setMoviesComboBox();
        setMovieInfo();
        setRentingInfo();
        setClientInfo();

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlReturnMovie = new javax.swing.JPanel();
        lblHeading = new javax.swing.JLabel();
        btnBack = new javax.swing.JButton();
        lblMovie = new javax.swing.JLabel();
        cmbMovies = new javax.swing.JComboBox<>();
        lblDatein = new javax.swing.JLabel();
        date_in = new com.toedter.calendar.JDateChooser();
        btnReturn = new javax.swing.JButton();
        btnCancel = new javax.swing.JButton();
        scrollMovieInfo = new javax.swing.JScrollPane();
        txtRentingInfo = new javax.swing.JTextArea();
        lblNote = new javax.swing.JLabel();
        Background = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(2000, 2000));

        pnlReturnMovie.setPreferredSize(new java.awt.Dimension(2000, 2000));
        pnlReturnMovie.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblHeading.setFont(new java.awt.Font("Calibri", 1, 36)); // NOI18N
        lblHeading.setForeground(new java.awt.Color(0, 255, 255));
        lblHeading.setText("RETURN MOVIE");
        pnlReturnMovie.add(lblHeading, new org.netbeans.lib.awtextra.AbsoluteConstraints(960, 60, 290, -1));

        btnBack.setBackground(new java.awt.Color(0, 255, 255));
        btnBack.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        btnBack.setText("BACK");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });
        pnlReturnMovie.add(btnBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(1040, 780, 110, -1));

        lblMovie.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        lblMovie.setForeground(new java.awt.Color(0, 255, 255));
        lblMovie.setText("MOVIE");
        pnlReturnMovie.add(lblMovie, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 390, 80, 40));

        cmbMovies.setBackground(new java.awt.Color(204, 255, 255));
        cmbMovies.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        cmbMovies.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbMoviesActionPerformed(evt);
            }
        });
        pnlReturnMovie.add(cmbMovies, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 390, 190, -1));

        lblDatein.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        lblDatein.setForeground(new java.awt.Color(0, 255, 255));
        lblDatein.setText("DATE IN");
        pnlReturnMovie.add(lblDatein, new org.netbeans.lib.awtextra.AbsoluteConstraints(1150, 490, 100, -1));

        date_in.setBackground(new java.awt.Color(204, 255, 255));
        pnlReturnMovie.add(date_in, new org.netbeans.lib.awtextra.AbsoluteConstraints(1110, 540, 180, 40));

        btnReturn.setBackground(new java.awt.Color(0, 255, 255));
        btnReturn.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        btnReturn.setText("RETURN");
        btnReturn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReturnActionPerformed(evt);
            }
        });
        pnlReturnMovie.add(btnReturn, new org.netbeans.lib.awtextra.AbsoluteConstraints(1557, 530, 140, -1));

        btnCancel.setBackground(new java.awt.Color(0, 255, 255));
        btnCancel.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        btnCancel.setText("CANCEL");
        btnCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelActionPerformed(evt);
            }
        });
        pnlReturnMovie.add(btnCancel, new org.netbeans.lib.awtextra.AbsoluteConstraints(1561, 620, 140, -1));

        txtRentingInfo.setEditable(false);
        txtRentingInfo.setBackground(new java.awt.Color(204, 255, 255));
        txtRentingInfo.setColumns(20);
        txtRentingInfo.setRows(5);
        scrollMovieInfo.setViewportView(txtRentingInfo);

        pnlReturnMovie.add(scrollMovieInfo, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 460, 360, 250));

        lblNote.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        lblNote.setForeground(new java.awt.Color(0, 255, 255));
        lblNote.setText("*IN CASE OF LATE RETURNS CLIENT IS SUBJECT TO FINE AMOUNT GENERATED BY THE SYSTEM.");
        pnlReturnMovie.add(lblNote, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 200, 970, -1));

        Background.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/4000x4000.jpg"))); // NOI18N
        pnlReturnMovie.add(Background, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 2000, 2000));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlReturnMovie, javax.swing.GroupLayout.PREFERRED_SIZE, 2000, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlReturnMovie, javax.swing.GroupLayout.PREFERRED_SIZE, 2000, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        this.setVisible(false);
        this.dispose();
        controller.BackHome();
    }//GEN-LAST:event_btnBackActionPerformed

    private void btnReturnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReturnActionPerformed

        if (rent_id.equalsIgnoreCase("False")) {
            JOptionPane.showMessageDialog(null, "Movie is not rented to any Client"); 
            return;
        }

        if (date_in.getDate() == null) {
            JOptionPane.showMessageDialog(null, "Date_in is empty"); 
            return;
        }
        
        calculateFine();
        int fineAmount = model.getFine_amount();
        returnMovie(renting_id, movie_id, datein, fineAmount);

        if (!model.getDate_in().isEmpty() && movieModel.getRent().equalsIgnoreCase("False")) {
            if (fineAmount == 0) {
                JOptionPane.showMessageDialog(null, "Movie is returned successfully for Renting Id: " + renting_id);
            } else {
                JOptionPane.showMessageDialog(null, "Movie is returned successfully for Rending Id: " + renting_id + ". Your fine amount is: " + fineAmount + "$");
            }
            clearFields();
        }

    }//GEN-LAST:event_btnReturnActionPerformed

    @Override
    public void calculateFine() {
        try {
            if (date_in.getDate() != null && !date_out.isEmpty()) {

                DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
                datein = dateFormat.format(date_in.getDate());
                Date in;

                in = new SimpleDateFormat("MM/dd/yyyy").parse(datein);

                Date out = new SimpleDateFormat("MM/dd/yyyy").parse(date_out);

                controller.calculateFine(in, out);
            }
        } catch (ParseException ex) {
            JOptionPane.showMessageDialog(null, ex);
        }

    }

    @Override
    public void returnMovie(int renting_id, int movieid, String date_in, int fineAmount) {
        
        controller.returnMovie(renting_id, date_in, fineAmount);

        
        controller.returnMovieUpdate(movieid);
    }

    private void btnCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelActionPerformed
        clearFields();
    }//GEN-LAST:event_btnCancelActionPerformed

    private void cmbMoviesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbMoviesActionPerformed
        client_id = movie_id = renting_id = 0;
        
        date_out = "";
        setMovieInfo();
        setRentingInfo();
        setClientInfo();
        calculateFine();
        if (model.getFine_amount() != 0) {
          
        }
    }//GEN-LAST:event_cmbMoviesActionPerformed

    int movie_id = 0;
    String rent_id;
    int renting_id = 0;
    int client_id = 0;
    String date_out;
    String datein;
    ArrayList<String> clientInfo = new ArrayList<String>();
    ArrayList<String> rentingInfo = new ArrayList<String>();

    @Override
    public void setMoviesComboBox() {
        controller.ShowAllMovies();
        ArrayList<Movie> movies = movieModel.getMovies();
        ArrayList<String> movieNames = new ArrayList<String>();
        int movieCount = 1;
        for (Movie movie : movies) {
            if (movieCount == 1) {
                movie_id = movie.getMovie_id();
            }
            movieNames.add(movie.getMovie_title());
            movieCount++;
        }

        cmbMovies.setModel(new DefaultComboBoxModel(movieNames.toArray()));

    }

    @Override
    public void setRentingInfo() {
        controller.ShowAllRentingInfo();
        ArrayList<MovieRentingInfo> MovieRentings = model.getMovieRentings();

        for (MovieRentingInfo renting : MovieRentings) {
            if (renting.getMovie_id() == movie_id && renting.getDate_in().isEmpty()) {
                renting_id = renting.getRenting_id();
                client_id = renting.getClient_id();
                date_out = renting.getDate_out();
                rentingInfo.add("\nRenting Id: " + renting.getRenting_id());
            }

        }

    }

    @Override
    public void setClientInfo() {
        clientInfo.clear();
        if (client_id != 0) {
            controller.ShowAllClients();
            ArrayList<Client> clients = clientModel.getClients();

            clientInfo.add("\n\nClient Info:");
            for (Client client : clients) {
                if (client.getClient_id() == client_id) {

                    clientInfo.add("\nClient ID: " + client_id + "\nClient Name: " + client.getName() + "\nClient Deleted: " + (client.getDeleted().equalsIgnoreCase("False")?"Active":"InActive"));
                }

            }

        }

        txtRentingInfo.setText("");
        for (String info : rentingInfo) {
            txtRentingInfo.setText(txtRentingInfo.getText() + info);
        }
        for (String client : clientInfo) {
            txtRentingInfo.setText(txtRentingInfo.getText() + client);
        }
    }

    @Override
    public void setMovieInfo() {
        controller.ShowAllMovies();

        ArrayList<Movie> movies = movieModel.getMovies();

        rentingInfo.clear();
        rentingInfo.add("\nRenting Info:");

        for (Movie movie : movies) {
            if (movie.getMovie_title().equals(cmbMovies.getSelectedItem().toString())) {
                movie_id = movie.getMovie_id();
                rent_id = movie.getRent();
                rentingInfo.add("\nMovie ID: " + movie_id + "\nMovie Title: " + movie.getMovie_title() + "\nMovie Rented: " +(movie.getRent().equalsIgnoreCase("True")?"Rent":"NotRented") );
            }
        }

    }

    @Override
    public void clearFields() {
        if (cmbMovies.getItemCount() > 0) {
            cmbMovies.setSelectedIndex(0);
        }
        date_in.setDate(null);
        
    }

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ReturnMoviePageGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Background;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnCancel;
    private javax.swing.JButton btnReturn;
    private javax.swing.JComboBox<String> cmbMovies;
    private com.toedter.calendar.JDateChooser date_in;
    private javax.swing.JLabel lblDatein;
    private javax.swing.JLabel lblHeading;
    private javax.swing.JLabel lblMovie;
    private javax.swing.JLabel lblNote;
    private javax.swing.JPanel pnlReturnMovie;
    private javax.swing.JScrollPane scrollMovieInfo;
    private javax.swing.JTextArea txtRentingInfo;
    // End of variables declaration//GEN-END:variables
}
