package View;

import javax.swing.JOptionPane;
import Model.IMovie;
import Controller.IMovieController;
import javax.swing.JFrame;

/**
 *
 * @author Nithisha Reddy Boyapati
 */
public class AddMoviePageGUI extends javax.swing.JFrame implements IAddMoviePageGUI {

    IMovieController controller;
    IMovie model;

    public AddMoviePageGUI() {
        initComponents();
    }

    public AddMoviePageGUI(IMovieController controller, IMovie model) {
        initComponents();
        
        setSize(2000, 2000);
        setResizable(false); 
        setLocationRelativeTo(null);
        
        this.model = model;
        this.controller = controller;

        model.registerObserver((IAddMoviePageGUI) this);

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlAddMovie = new javax.swing.JPanel();
        lblHeading = new javax.swing.JLabel();
        lblMovieId = new javax.swing.JLabel();
        lblMovieTitle = new javax.swing.JLabel();
        txtMovieId = new javax.swing.JTextField();
        txtMovieTitle = new javax.swing.JTextField();
        btnSubmit = new javax.swing.JButton();
        btnCancel = new javax.swing.JButton();
        lblNote = new javax.swing.JLabel();
        btnBack = new javax.swing.JButton();
        Background = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(2000, 2000));

        pnlAddMovie.setPreferredSize(new java.awt.Dimension(2000, 2000));
        pnlAddMovie.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblHeading.setFont(new java.awt.Font("Calibri", 1, 36)); // NOI18N
        lblHeading.setForeground(new java.awt.Color(0, 255, 255));
        lblHeading.setText("ADD MOVIE");
        pnlAddMovie.add(lblHeading, new org.netbeans.lib.awtextra.AbsoluteConstraints(910, 110, -1, -1));

        lblMovieId.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        lblMovieId.setForeground(new java.awt.Color(0, 255, 255));
        lblMovieId.setText("MOVIE ID");
        pnlAddMovie.add(lblMovieId, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 410, 110, 40));

        lblMovieTitle.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        lblMovieTitle.setForeground(new java.awt.Color(0, 255, 255));
        lblMovieTitle.setText("MOVIE TITLE");
        pnlAddMovie.add(lblMovieTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 580, -1, -1));

        txtMovieId.setEditable(false);
        txtMovieId.setBackground(new java.awt.Color(204, 204, 204));
        txtMovieId.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        pnlAddMovie.add(txtMovieId, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 390, 440, 70));

        txtMovieTitle.setBackground(new java.awt.Color(204, 255, 255));
        txtMovieTitle.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        pnlAddMovie.add(txtMovieTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 570, 430, 70));

        btnSubmit.setBackground(new java.awt.Color(0, 255, 255));
        btnSubmit.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        btnSubmit.setText("SUBMIT");
        btnSubmit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSubmitActionPerformed(evt);
            }
        });
        pnlAddMovie.add(btnSubmit, new org.netbeans.lib.awtextra.AbsoluteConstraints(1400, 440, 140, 50));

        btnCancel.setBackground(new java.awt.Color(0, 255, 255));
        btnCancel.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        btnCancel.setText("CANCEL");
        btnCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelActionPerformed(evt);
            }
        });
        pnlAddMovie.add(btnCancel, new org.netbeans.lib.awtextra.AbsoluteConstraints(1410, 540, 140, 50));

        lblNote.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        lblNote.setForeground(new java.awt.Color(0, 255, 255));
        lblNote.setText("*AFTER SUCCESSFUL ADDITION OF A MOVIE IT'S ID WILL BE GENERATED.");
        pnlAddMovie.add(lblNote, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 240, 790, -1));

        btnBack.setBackground(new java.awt.Color(0, 255, 255));
        btnBack.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        btnBack.setText("BACK");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });
        pnlAddMovie.add(btnBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(1000, 790, 130, 50));

        Background.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/4000x4000.jpg"))); // NOI18N
        pnlAddMovie.add(Background, new org.netbeans.lib.awtextra.AbsoluteConstraints(-100, 0, 2120, 2000));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnlAddMovie, javax.swing.GroupLayout.PREFERRED_SIZE, 2000, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlAddMovie, javax.swing.GroupLayout.PREFERRED_SIZE, 2000, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        this.setVisible(false);
        this.dispose();
        controller.BackHome();
    }//GEN-LAST:event_btnBackActionPerformed

    private void btnSubmitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSubmitActionPerformed
        if (txtMovieTitle.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Movie Title is Empty");
            return; 
        }

        addMovie(txtMovieTitle.getText().trim());
        if (model.getMovie_id() == 0) {
            JOptionPane.showMessageDialog(null, "Movie already exists in the system");
        } else {
            txtMovieId.setText("" + model.getMovie_id());
            JOptionPane.showMessageDialog(null, "Movie got added successfully. Movie ID is " + model.getMovie_id());
            clearFields();
        }
    }//GEN-LAST:event_btnSubmitActionPerformed

    private void btnCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelActionPerformed
        clearFields();
    }//GEN-LAST:event_btnCancelActionPerformed

    @Override
    public void addMovie(String movieTitle) {
        controller.AddMovie(movieTitle);
    }

    @Override
    public void clearFields() {
        txtMovieId.setText("");
        txtMovieTitle.setText("");
    }

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AddMoviePageGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Background;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnCancel;
    private javax.swing.JButton btnSubmit;
    private javax.swing.JLabel lblHeading;
    private javax.swing.JLabel lblMovieId;
    private javax.swing.JLabel lblMovieTitle;
    private javax.swing.JLabel lblNote;
    private javax.swing.JPanel pnlAddMovie;
    private javax.swing.JTextField txtMovieId;
    private javax.swing.JTextField txtMovieTitle;
    // End of variables declaration//GEN-END:variables
}
