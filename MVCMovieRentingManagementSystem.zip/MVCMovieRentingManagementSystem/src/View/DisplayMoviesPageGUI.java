package View;

import Model.Movie;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import Model.IMovie;
import Controller.IMovieController;

/**
 *
 * @author Nithisha Reddy Boyapati
 */
public class DisplayMoviesPageGUI extends javax.swing.JFrame implements IDisplayMoviesPageGUI {

    IMovieController controller;
    IMovie model;

    public DisplayMoviesPageGUI() {
        initComponents();
    }

    public DisplayMoviesPageGUI(IMovieController controller, IMovie model) {
        initComponents();
        
        setSize(2000, 2000);
        setResizable(false); 
        setLocationRelativeTo(null); 
        
        this.model = model;
        this.controller = controller;

        model.registerObserver((IDisplayMoviesPageGUI) this);
        show_Movies();
          jTable_Movies.setFillsViewportHeight(true);
        jTable_Movies.getTableHeader().setBackground(new Color(0,255,255));
        jTable_Movies.getTableHeader().setOpaque(false);
        jTable_Movies.setGridColor(new Color(0, 255, 255));

    }

    @Override
    public void show_Movies() {

        
        controller.ShowAllMovies();
       
        ArrayList<Movie> movies = model.getMovies();
       
        DefaultTableModel model = (DefaultTableModel) jTable_Movies.getModel();
        model.setRowCount(0);
        Object[] row = new Object[3];
        for (int i = 0; i < movies.size(); i++) {
            row[0] = movies.get(i).getMovie_id();
            row[1] = movies.get(i).getMovie_title();
            row[2] = movies.get(i).getRent().equalsIgnoreCase("True") ? "Rent" : "NotRented";
            model.addRow(row);

        }

    }

    @Override
    public void show_CurrentRentMovies() {

        controller.show_CurrentRentedMovies();
        
        ArrayList<Movie> movies = model.getMovies();
        DefaultTableModel model = (DefaultTableModel) jTable_Movies.getModel();
        model.setRowCount(0);
        Object[] row = new Object[3];
        for (int i = 0; i < movies.size(); i++) {
            row[0] = movies.get(i).getMovie_id();
            row[1] = movies.get(i).getMovie_title();
            row[2] = movies.get(i).getRent().equalsIgnoreCase("True") ? "Rented" : "NotRented";
            model.addRow(row);
        }
    }

    @Override
    public void clearFields() {
        txtMovieId.setText("");
        txtMovieName.setText("");
        txtRentStatus.setText("");

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlShowMovies = new javax.swing.JPanel();
        txtHeading = new javax.swing.JLabel();
        btnBack = new javax.swing.JButton();
        scrollJTableMovies = new javax.swing.JScrollPane();
        scrollJTableMovies1 = new javax.swing.JScrollPane();
        jTable_Movies = new javax.swing.JTable();
        lblMovieId = new javax.swing.JLabel();
        lblMovieName = new javax.swing.JLabel();
        lblRentStatus = new javax.swing.JLabel();
        txtMovieId = new javax.swing.JTextField();
        txtMovieName = new javax.swing.JTextField();
        txtRentStatus = new javax.swing.JTextField();
        btnShowAllMovies = new javax.swing.JButton();
        btnShowCurrentRentMovies = new javax.swing.JButton();
        lblNote = new javax.swing.JLabel();
        Background = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(2000, 2000));

        pnlShowMovies.setPreferredSize(new java.awt.Dimension(2000, 2000));
        pnlShowMovies.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtHeading.setFont(new java.awt.Font("Calibri", 1, 36)); // NOI18N
        txtHeading.setForeground(new java.awt.Color(0, 255, 255));
        txtHeading.setText("DISPLAY MOVIES");
        pnlShowMovies.add(txtHeading, new org.netbeans.lib.awtextra.AbsoluteConstraints(1070, 40, -1, -1));

        btnBack.setBackground(new java.awt.Color(0, 255, 255));
        btnBack.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        btnBack.setText("BACK");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });
        pnlShowMovies.add(btnBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 790, -1, -1));

        scrollJTableMovies.setBackground(new java.awt.Color(204, 255, 255));

        scrollJTableMovies1.setBackground(new java.awt.Color(204, 255, 255));

        jTable_Movies.setBackground(new java.awt.Color(204, 255, 255));
        jTable_Movies.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Movie ID", "Movie Name", "Rent Status"
            }
        ));
        jTable_Movies.setGridColor(new java.awt.Color(204, 255, 255));
        jTable_Movies.setSelectionBackground(new java.awt.Color(0, 255, 255));
        jTable_Movies.setSelectionForeground(new java.awt.Color(0, 0, 0));
        jTable_Movies.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable_MoviesMouseClicked(evt);
            }
        });
        scrollJTableMovies1.setViewportView(jTable_Movies);
        if (jTable_Movies.getColumnModel().getColumnCount() > 0) {
            jTable_Movies.getColumnModel().getColumn(0).setPreferredWidth(20);
            jTable_Movies.getColumnModel().getColumn(2).setPreferredWidth(10);
        }

        scrollJTableMovies.setViewportView(scrollJTableMovies1);

        pnlShowMovies.add(scrollJTableMovies, new org.netbeans.lib.awtextra.AbsoluteConstraints(233, 324, 730, 380));

        lblMovieId.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        lblMovieId.setForeground(new java.awt.Color(0, 255, 255));
        lblMovieId.setText("MOVIE ID");
        pnlShowMovies.add(lblMovieId, new org.netbeans.lib.awtextra.AbsoluteConstraints(1140, 370, 120, -1));

        lblMovieName.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        lblMovieName.setForeground(new java.awt.Color(0, 255, 255));
        lblMovieName.setText("MOVIE NAME");
        pnlShowMovies.add(lblMovieName, new org.netbeans.lib.awtextra.AbsoluteConstraints(1140, 450, 150, -1));

        lblRentStatus.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        lblRentStatus.setForeground(new java.awt.Color(0, 255, 255));
        lblRentStatus.setText(" RENT STATUS");
        pnlShowMovies.add(lblRentStatus, new org.netbeans.lib.awtextra.AbsoluteConstraints(1140, 540, -1, 40));

        txtMovieId.setEditable(false);
        txtMovieId.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        txtMovieId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtMovieIdActionPerformed(evt);
            }
        });
        pnlShowMovies.add(txtMovieId, new org.netbeans.lib.awtextra.AbsoluteConstraints(1370, 360, 250, -1));

        txtMovieName.setEditable(false);
        txtMovieName.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        pnlShowMovies.add(txtMovieName, new org.netbeans.lib.awtextra.AbsoluteConstraints(1380, 450, 240, -1));

        txtRentStatus.setEditable(false);
        txtRentStatus.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        pnlShowMovies.add(txtRentStatus, new org.netbeans.lib.awtextra.AbsoluteConstraints(1380, 530, 250, -1));

        btnShowAllMovies.setBackground(new java.awt.Color(0, 255, 255));
        btnShowAllMovies.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        btnShowAllMovies.setText("DISPLAY ALL MOVIES");
        btnShowAllMovies.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnShowAllMoviesActionPerformed(evt);
            }
        });
        pnlShowMovies.add(btnShowAllMovies, new org.netbeans.lib.awtextra.AbsoluteConstraints(1270, 650, 320, 50));

        btnShowCurrentRentMovies.setBackground(new java.awt.Color(0, 255, 255));
        btnShowCurrentRentMovies.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        btnShowCurrentRentMovies.setText("DISPLAY CURRENT RENTED MOVIES");
        btnShowCurrentRentMovies.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnShowCurrentRentMoviesActionPerformed(evt);
            }
        });
        pnlShowMovies.add(btnShowCurrentRentMovies, new org.netbeans.lib.awtextra.AbsoluteConstraints(1250, 760, -1, 50));

        lblNote.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        lblNote.setForeground(new java.awt.Color(0, 255, 255));
        lblNote.setText("*THIS PAGE WILL DISPLAY ALL AND CURRENT RENTED MOVIES.");
        pnlShowMovies.add(lblNote, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 170, 660, 20));

        Background.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/4000x4000.jpg"))); // NOI18N
        pnlShowMovies.add(Background, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 2000, 2000));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlShowMovies, javax.swing.GroupLayout.PREFERRED_SIZE, 2000, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlShowMovies, javax.swing.GroupLayout.PREFERRED_SIZE, 2000, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnShowAllMoviesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnShowAllMoviesActionPerformed
        show_Movies();
        clearFields();
    }//GEN-LAST:event_btnShowAllMoviesActionPerformed

    private void btnShowCurrentRentMoviesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnShowCurrentRentMoviesActionPerformed
        show_CurrentRentMovies();
        clearFields();
    }//GEN-LAST:event_btnShowCurrentRentMoviesActionPerformed

    private void jTable_MoviesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable_MoviesMouseClicked
        int i = jTable_Movies.getSelectedRow();
        TableModel tableModel = jTable_Movies.getModel();

        txtMovieId.setText(tableModel.getValueAt(i, 0).toString());
        txtMovieName.setText(tableModel.getValueAt(i, 1).toString());
        txtRentStatus.setText(tableModel.getValueAt(i, 2).toString());
    }//GEN-LAST:event_jTable_MoviesMouseClicked

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        this.setVisible(false);
        this.dispose();
        controller.BackHome();
    }//GEN-LAST:event_btnBackActionPerformed

    private void txtMovieIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMovieIdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtMovieIdActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DisplayMoviesPageGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Background;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnShowAllMovies;
    private javax.swing.JButton btnShowCurrentRentMovies;
    private javax.swing.JTable jTable_Movies;
    private javax.swing.JLabel lblMovieId;
    private javax.swing.JLabel lblMovieName;
    private javax.swing.JLabel lblNote;
    private javax.swing.JLabel lblRentStatus;
    private javax.swing.JPanel pnlShowMovies;
    private javax.swing.JScrollPane scrollJTableMovies;
    private javax.swing.JScrollPane scrollJTableMovies1;
    private javax.swing.JLabel txtHeading;
    private javax.swing.JTextField txtMovieId;
    private javax.swing.JTextField txtMovieName;
    private javax.swing.JTextField txtRentStatus;
    // End of variables declaration//GEN-END:variables
}
