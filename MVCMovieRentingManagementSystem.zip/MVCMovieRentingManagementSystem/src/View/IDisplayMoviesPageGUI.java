package View;

/**
 *
 * @author Nithisha Reddy Boyapati
 */
public interface IDisplayMoviesPageGUI {

    public void show_Movies();

    public void clearFields();

    public void show_CurrentRentMovies();
}
