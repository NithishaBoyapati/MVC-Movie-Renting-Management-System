
package View;

import Controller.IClientController;
import Model.Client;
import Model.IClient;
import java.awt.Color;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

/**
 *
 * @author Nithisha Reddy Boyapati
 */
public class DisplayClientsPageGUI extends javax.swing.JFrame implements IDisplayClientsPageGUI{

    IClientController controller;
    IClient model;
    
    public DisplayClientsPageGUI() {
        initComponents();
    }

     public DisplayClientsPageGUI(IClientController controller, IClient model) {
        initComponents();
        
        setSize(2000, 2000);
        setResizable(false); 
        setLocationRelativeTo(null); 
        
        this.model = model;
        this.controller = controller;

        model.registerObserver((IDisplayClientsPageGUI) this);
        show_Clients();
        jTable_Clients.setFillsViewportHeight(true);
        jTable_Clients.getTableHeader().setBackground(new Color(0,255,255));
        jTable_Clients.getTableHeader().setOpaque(false);
        jTable_Clients.setGridColor(new Color(0, 255, 255));

    }

    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlShowAllClients = new javax.swing.JPanel();
        lblHeading = new javax.swing.JLabel();
        btnBack = new javax.swing.JButton();
        scrollJTableClients = new javax.swing.JScrollPane();
        scrollJTableClients1 = new javax.swing.JScrollPane();
        jTable_Clients = new javax.swing.JTable();
        lblClientId = new javax.swing.JLabel();
        txtDeleted = new javax.swing.JTextField();
        txtClientId = new javax.swing.JTextField();
        txtFirstName = new javax.swing.JTextField();
        txtName = new javax.swing.JTextField();
        txtLastName = new javax.swing.JTextField();
        lblFirstName = new javax.swing.JLabel();
        lblLastName = new javax.swing.JLabel();
        lblName = new javax.swing.JLabel();
        lblDeleted = new javax.swing.JLabel();
        lblNote = new javax.swing.JLabel();
        Background = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(2000, 2000));

        pnlShowAllClients.setPreferredSize(new java.awt.Dimension(2000, 2000));
        pnlShowAllClients.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblHeading.setFont(new java.awt.Font("Calibri", 1, 36)); // NOI18N
        lblHeading.setForeground(new java.awt.Color(0, 255, 255));
        lblHeading.setText("DISPLAY ALL CLIENTS");
        pnlShowAllClients.add(lblHeading, new org.netbeans.lib.awtextra.AbsoluteConstraints(910, 50, -1, -1));

        btnBack.setBackground(new java.awt.Color(0, 255, 255));
        btnBack.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        btnBack.setText("BACK");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });
        pnlShowAllClients.add(btnBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 790, -1, -1));

        scrollJTableClients.setBackground(new java.awt.Color(204, 255, 255));

        scrollJTableClients1.setBackground(new java.awt.Color(204, 255, 255));

        jTable_Clients.setBackground(new java.awt.Color(204, 255, 255));
        jTable_Clients.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Name", "Client ID", "Deleted"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable_Clients.setGridColor(new java.awt.Color(204, 255, 255));
        jTable_Clients.setSelectionBackground(new java.awt.Color(0, 255, 255));
        jTable_Clients.setSelectionForeground(new java.awt.Color(0, 0, 0));
        jTable_Clients.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable_ClientsMouseClicked(evt);
            }
        });
        scrollJTableClients1.setViewportView(jTable_Clients);

        scrollJTableClients.setViewportView(scrollJTableClients1);

        pnlShowAllClients.add(scrollJTableClients, new org.netbeans.lib.awtextra.AbsoluteConstraints(356, 352, 700, 350));

        lblClientId.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        lblClientId.setForeground(new java.awt.Color(0, 255, 255));
        lblClientId.setText("CLIENTID");
        pnlShowAllClients.add(lblClientId, new org.netbeans.lib.awtextra.AbsoluteConstraints(1120, 370, -1, -1));

        txtDeleted.setEditable(false);
        txtDeleted.setBackground(new java.awt.Color(204, 204, 204));
        txtDeleted.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        txtDeleted.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDeletedActionPerformed(evt);
            }
        });
        pnlShowAllClients.add(txtDeleted, new org.netbeans.lib.awtextra.AbsoluteConstraints(1300, 690, 250, -1));

        txtClientId.setEditable(false);
        txtClientId.setBackground(new java.awt.Color(204, 204, 204));
        txtClientId.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        txtClientId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtClientIdActionPerformed(evt);
            }
        });
        pnlShowAllClients.add(txtClientId, new org.netbeans.lib.awtextra.AbsoluteConstraints(1290, 360, 250, -1));

        txtFirstName.setEditable(false);
        txtFirstName.setBackground(new java.awt.Color(204, 204, 204));
        txtFirstName.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        pnlShowAllClients.add(txtFirstName, new org.netbeans.lib.awtextra.AbsoluteConstraints(1290, 440, 250, -1));

        txtName.setEditable(false);
        txtName.setBackground(new java.awt.Color(204, 204, 204));
        txtName.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        pnlShowAllClients.add(txtName, new org.netbeans.lib.awtextra.AbsoluteConstraints(1300, 610, 250, -1));

        txtLastName.setEditable(false);
        txtLastName.setBackground(new java.awt.Color(204, 204, 204));
        txtLastName.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        pnlShowAllClients.add(txtLastName, new org.netbeans.lib.awtextra.AbsoluteConstraints(1300, 520, 250, -1));

        lblFirstName.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        lblFirstName.setForeground(new java.awt.Color(0, 255, 255));
        lblFirstName.setText("FIRSTNAME");
        pnlShowAllClients.add(lblFirstName, new org.netbeans.lib.awtextra.AbsoluteConstraints(1130, 450, -1, -1));

        lblLastName.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        lblLastName.setForeground(new java.awt.Color(0, 255, 255));
        lblLastName.setText("LASTNAME");
        pnlShowAllClients.add(lblLastName, new org.netbeans.lib.awtextra.AbsoluteConstraints(1130, 530, -1, -1));

        lblName.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        lblName.setForeground(new java.awt.Color(0, 255, 255));
        lblName.setText("NAME");
        pnlShowAllClients.add(lblName, new org.netbeans.lib.awtextra.AbsoluteConstraints(1140, 620, -1, -1));

        lblDeleted.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        lblDeleted.setForeground(new java.awt.Color(0, 255, 255));
        lblDeleted.setText("DELETED");
        pnlShowAllClients.add(lblDeleted, new org.netbeans.lib.awtextra.AbsoluteConstraints(1140, 690, -1, -1));

        lblNote.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        lblNote.setForeground(new java.awt.Color(0, 255, 255));
        lblNote.setText("*THIS PAGE DISPLAYS INACTIVE CLIENTS ALONG WITH ACTIVE ONE'S.");
        pnlShowAllClients.add(lblNote, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 180, 710, 22));

        Background.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/4000x4000.jpg"))); // NOI18N
        pnlShowAllClients.add(Background, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 2000, 2000));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlShowAllClients, javax.swing.GroupLayout.PREFERRED_SIZE, 2000, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlShowAllClients, javax.swing.GroupLayout.PREFERRED_SIZE, 2000, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
    private void jTable_ClientsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable_ClientsMouseClicked
        int i = jTable_Clients.getSelectedRow();
        TableModel tableModel = jTable_Clients.getModel();
     
        txtClientId.setText(tableModel.getValueAt(i, 1).toString());
        txtFirstName.setText(tableModel.getValueAt(i, 0).toString().substring(0, tableModel.getValueAt(i, 0).toString().indexOf(" ")));
        txtLastName.setText(tableModel.getValueAt(i, 0).toString().substring(tableModel.getValueAt(i, 0).toString().indexOf(" ")+1));
        txtName.setText(tableModel.getValueAt(i, 0).toString());
        txtDeleted.setText(tableModel.getValueAt(i, 2).toString());
       
    }//GEN-LAST:event_jTable_ClientsMouseClicked

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
       this.setVisible(false);
        this.dispose();
        controller.BackHome();
    }//GEN-LAST:event_btnBackActionPerformed

    private void txtDeletedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDeletedActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDeletedActionPerformed

    private void txtClientIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtClientIdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtClientIdActionPerformed

    @Override
   public void show_Clients() {
       
        controller.ShowAllClients();
        
        ArrayList<Client> clients = model.getClients();

        DefaultTableModel model = (DefaultTableModel) jTable_Clients.getModel();
        model.setRowCount(0);
        Object[] row = new Object[3];
        for (int i = 0; i < clients.size(); i++) {
            row[0] = clients.get(i).getName();
            row[1] = clients.get(i).getClient_id();
            row[2] = clients.get(i).getDeleted().equalsIgnoreCase("False")? "Active" : "InActive";
            model.addRow(row);

        }

    }
   
    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DisplayClientsPageGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Background;
    private javax.swing.JButton btnBack;
    private javax.swing.JTable jTable_Clients;
    private javax.swing.JLabel lblClientId;
    private javax.swing.JLabel lblDeleted;
    private javax.swing.JLabel lblFirstName;
    private javax.swing.JLabel lblHeading;
    private javax.swing.JLabel lblLastName;
    private javax.swing.JLabel lblName;
    private javax.swing.JLabel lblNote;
    private javax.swing.JPanel pnlShowAllClients;
    private javax.swing.JScrollPane scrollJTableClients;
    private javax.swing.JScrollPane scrollJTableClients1;
    private javax.swing.JTextField txtClientId;
    private javax.swing.JTextField txtDeleted;
    private javax.swing.JTextField txtFirstName;
    private javax.swing.JTextField txtLastName;
    private javax.swing.JTextField txtName;
    // End of variables declaration//GEN-END:variables
}
