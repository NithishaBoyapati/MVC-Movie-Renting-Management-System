package View;

import Controller.SelectFilesController;
import Model.FilePaths;
import Model.IFilePaths;
import java.io.File;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;
import Controller.ISelectFilesController;

/**
 *
 * @author Nithisha Reddy Boyapati
 */
public class SelectFilesPageGUI extends javax.swing.JFrame implements ISelectFilesPageGUI {

    ISelectFilesController controller;
    IFilePaths model;

    public SelectFilesPageGUI() {
        initComponents();
    }

    public SelectFilesPageGUI(ISelectFilesController controller, IFilePaths model) {
        initComponents();
        
        setSize(2000, 2000);
        setResizable(false); 
        setLocationRelativeTo(null); 
        
        this.model = model;
        this.controller = controller;
        model.registerObserver((ISelectFilesPageGUI) this);

        
        txtMoviesPath.setText(System.getProperty("user.dir") + "\\src\\InputFiles\\movies.txt");
        txtClientsPath.setText(System.getProperty("user.dir") + "\\src\\InputFiles\\clients.txt");
        txtRentingPath.setText(System.getProperty("user.dir") + "\\src\\InputFiles\\rental_info.txt");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlMovieRentingSystem = new javax.swing.JPanel();
        lblHeading = new javax.swing.JLabel();
        txtClientsPath = new javax.swing.JTextField();
        txtMoviesPath = new javax.swing.JTextField();
        btnHome = new javax.swing.JButton();
        btnClientsFilePath = new javax.swing.JButton();
        btnMoviesFilePath = new javax.swing.JButton();
        btnExit = new javax.swing.JButton();
        btnRentingFilePath = new javax.swing.JButton();
        txtRentingPath = new javax.swing.JTextField();
        Background = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(2000, 2000));

        pnlMovieRentingSystem.setBackground(new java.awt.Color(15, 22, 38));
        pnlMovieRentingSystem.setPreferredSize(new java.awt.Dimension(2000, 2000));
        pnlMovieRentingSystem.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblHeading.setBackground(new java.awt.Color(0, 255, 255));
        lblHeading.setFont(new java.awt.Font("Calibri", 1, 48)); // NOI18N
        lblHeading.setForeground(new java.awt.Color(0, 255, 255));
        lblHeading.setText("MOVIE RENTING MANAGEMANT SYSTEM");
        pnlMovieRentingSystem.add(lblHeading, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 60, 850, -1));

        txtClientsPath.setEditable(false);
        txtClientsPath.setBackground(new java.awt.Color(204, 255, 255));
        txtClientsPath.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        pnlMovieRentingSystem.add(txtClientsPath, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 350, 1050, 50));

        txtMoviesPath.setEditable(false);
        txtMoviesPath.setBackground(new java.awt.Color(204, 255, 255));
        txtMoviesPath.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        pnlMovieRentingSystem.add(txtMoviesPath, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 480, 1050, 50));

        btnHome.setBackground(new java.awt.Color(0, 255, 255));
        btnHome.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        btnHome.setText(" HOME");
        btnHome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHomeActionPerformed(evt);
            }
        });
        pnlMovieRentingSystem.add(btnHome, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 780, 150, -1));

        btnClientsFilePath.setBackground(new java.awt.Color(0, 255, 255));
        btnClientsFilePath.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        btnClientsFilePath.setText("CLIENTS FILE PATH");
        btnClientsFilePath.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClientsFilePathActionPerformed(evt);
            }
        });
        pnlMovieRentingSystem.add(btnClientsFilePath, new org.netbeans.lib.awtextra.AbsoluteConstraints(1480, 350, 250, 40));

        btnMoviesFilePath.setBackground(new java.awt.Color(0, 255, 255));
        btnMoviesFilePath.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        btnMoviesFilePath.setText("MOVIES FILE PATH");
        btnMoviesFilePath.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMoviesFilePathActionPerformed(evt);
            }
        });
        pnlMovieRentingSystem.add(btnMoviesFilePath, new org.netbeans.lib.awtextra.AbsoluteConstraints(1480, 480, 250, 40));

        btnExit.setBackground(new java.awt.Color(0, 255, 255));
        btnExit.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        btnExit.setText("EXIT");
        btnExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExitActionPerformed(evt);
            }
        });
        pnlMovieRentingSystem.add(btnExit, new org.netbeans.lib.awtextra.AbsoluteConstraints(1130, 780, 130, -1));

        btnRentingFilePath.setBackground(new java.awt.Color(0, 255, 255));
        btnRentingFilePath.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        btnRentingFilePath.setText("RENTING FILE PATH");
        btnRentingFilePath.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRentingFilePathActionPerformed(evt);
            }
        });
        pnlMovieRentingSystem.add(btnRentingFilePath, new org.netbeans.lib.awtextra.AbsoluteConstraints(1490, 600, 240, 40));

        txtRentingPath.setEditable(false);
        txtRentingPath.setBackground(new java.awt.Color(204, 255, 255));
        txtRentingPath.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        pnlMovieRentingSystem.add(txtRentingPath, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 610, 1060, 50));

        Background.setBackground(new java.awt.Color(237, 41, 57));
        Background.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/4000x4000.jpg"))); // NOI18N
        Background.setText("jLabel2");
        pnlMovieRentingSystem.add(Background, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 2000, 2000));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlMovieRentingSystem, javax.swing.GroupLayout.PREFERRED_SIZE, 2000, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlMovieRentingSystem, javax.swing.GroupLayout.PREFERRED_SIZE, 2000, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnClientsFilePathActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClientsFilePathActionPerformed
        JFileChooser file = new JFileChooser();
        file.setCurrentDirectory(new File(System.getProperty("user.dir") + "\\src\\InputFiles"));
        FileNameExtensionFilter filter = new FileNameExtensionFilter("*.txt", "txt");
        file.addChoosableFileFilter(filter);
        int result = file.showSaveDialog(null);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = file.getSelectedFile();
            String path = selectedFile.getAbsolutePath();
            txtClientsPath.setText(path);
        }
    }//GEN-LAST:event_btnClientsFilePathActionPerformed

    private void btnMoviesFilePathActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMoviesFilePathActionPerformed
        JFileChooser file = new JFileChooser();
        file.setCurrentDirectory(new File(System.getProperty("user.dir") + "\\src\\InputFiles"));
        FileNameExtensionFilter filter = new FileNameExtensionFilter("*.txt", "txt");
        file.addChoosableFileFilter(filter);
        int result = file.showSaveDialog(null);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = file.getSelectedFile();
            String path = selectedFile.getAbsolutePath();
            txtMoviesPath.setText(path);
        }
    }//GEN-LAST:event_btnMoviesFilePathActionPerformed

    private void btnHomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHomeActionPerformed
        
        SetFilePaths(txtClientsPath.getText(), txtMoviesPath.getText(),txtRentingPath.getText());
        this.setVisible(false);
        controller.GoHome();
    }//GEN-LAST:event_btnHomeActionPerformed

    private void btnExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExitActionPerformed
          System.exit(0);
    }//GEN-LAST:event_btnExitActionPerformed

    private void btnRentingFilePathActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRentingFilePathActionPerformed
       JFileChooser file = new JFileChooser();
        file.setCurrentDirectory(new File(System.getProperty("user.dir") + "\\src\\InputFiles"));
        FileNameExtensionFilter filter = new FileNameExtensionFilter("*.txt", "txt");
        file.addChoosableFileFilter(filter);
        int result = file.showSaveDialog(null);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = file.getSelectedFile();
            String path = selectedFile.getAbsolutePath();
            txtRentingPath.setText(path);
        }
    }//GEN-LAST:event_btnRentingFilePathActionPerformed

    @Override
    public void SetFilePaths(String clientsPath, String moviesPath,String rentingPath) {
        controller.SetFilePaths(clientsPath, moviesPath,rentingPath);
        model.getClientFilePath();

    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                IFilePaths model = new FilePaths();
                ISelectFilesController controller = new SelectFilesController(model);

            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Background;
    private javax.swing.JButton btnClientsFilePath;
    private javax.swing.JButton btnExit;
    private javax.swing.JButton btnHome;
    private javax.swing.JButton btnMoviesFilePath;
    private javax.swing.JButton btnRentingFilePath;
    private javax.swing.JLabel lblHeading;
    private javax.swing.JPanel pnlMovieRentingSystem;
    private javax.swing.JTextField txtClientsPath;
    private javax.swing.JTextField txtMoviesPath;
    private javax.swing.JTextField txtRentingPath;
    // End of variables declaration//GEN-END:variables
}
