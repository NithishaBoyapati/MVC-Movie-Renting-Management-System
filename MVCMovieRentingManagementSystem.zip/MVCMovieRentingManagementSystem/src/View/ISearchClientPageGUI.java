package View;

/**
 *
 * @author Nithisha Reddy Boyapati
 */
public interface ISearchClientPageGUI {

    public void searchClient(String firstName, String lastName);

    public void show_Clients();

}
