package View;

import Model.Movie;
import Model.Client;
import Model.IClient;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import Model.IMovie;
import Model.IMovieRentingInfo;
import Controller.IMovieRentingController;

/**
 *
 * @author Nithisha Reddy Boyapati
 */
public class RentMoviePageGUI extends javax.swing.JFrame implements IRentMoviePageGUI {

    IMovieRentingController controller;
    IMovieRentingInfo model;
    IMovie movieModel;
    IClient clientModel;

    public RentMoviePageGUI() {
        initComponents();
    }

    public RentMoviePageGUI(IMovieRentingController controller, IMovieRentingInfo model, IMovie movieModel, IClient clientModel) {
        initComponents();
        
        setSize(2000, 2000);
        setResizable(false); 
        setLocationRelativeTo(null); 
        
        this.model = model;
        this.controller = controller;
        this.movieModel = movieModel;
        this.clientModel = clientModel;
        date_out.setDate(new Date());
        model.registerObserver((IRentMoviePageGUI) this);
        setClientsComboBox();
        setMoviesComboBox();
        setClientInfo();
        setMovieInfo();
    }

    @Override
    public void setClientsComboBox() {
        controller.ShowAllClients();
        ArrayList<Client> clients = clientModel.getClients();
        ArrayList<String> clientNames = new ArrayList<String>();
        int clientCount = 1;
        for (Client client : clients) {
            if (clientCount == 1) {
                client_id = client.getClient_id();
            }
            clientNames.add(client.getName());
            clientCount++;
        }

        cmbClients.setModel(new DefaultComboBoxModel(clientNames.toArray()));

    }

    @Override
    public void setMoviesComboBox() {
        controller.ShowAllMovies();
        ArrayList<Movie> movies = movieModel.getMovies();
        ArrayList<String> movieNames = new ArrayList<String>();
        int movieCount = 1;
        for (Movie movie : movies) {
            if (movieCount == 1) {
                movie_id = movie.getMovie_id();
            }
            movieNames.add(movie.getMovie_title());
            movieCount++;
        }

        cmbMovies.setModel(new DefaultComboBoxModel(movieNames.toArray()));

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlRentMovie = new javax.swing.JPanel();
        lblHeading = new javax.swing.JLabel();
        btnBack = new javax.swing.JButton();
        lblClient = new javax.swing.JLabel();
        lblMovie = new javax.swing.JLabel();
        btnRent = new javax.swing.JButton();
        btnCancel = new javax.swing.JButton();
        lblNote = new javax.swing.JLabel();
        lblRentingId = new javax.swing.JLabel();
        txtRentingId = new javax.swing.JTextField();
        ScrollMovieInfo = new javax.swing.JScrollPane();
        txtRentingInfo = new javax.swing.JTextArea();
        cmbClients = new javax.swing.JComboBox<>();
        cmbMovies = new javax.swing.JComboBox<>();
        date_out = new com.toedter.calendar.JDateChooser();
        lbldateout = new javax.swing.JLabel();
        background = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(2000, 2000));

        pnlRentMovie.setForeground(new java.awt.Color(0, 255, 255));
        pnlRentMovie.setPreferredSize(new java.awt.Dimension(2000, 2000));
        pnlRentMovie.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblHeading.setFont(new java.awt.Font("Calibri", 1, 36)); // NOI18N
        lblHeading.setForeground(new java.awt.Color(0, 255, 255));
        lblHeading.setText("RENT MOVIE");
        pnlRentMovie.add(lblHeading, new org.netbeans.lib.awtextra.AbsoluteConstraints(900, 40, 210, 50));

        btnBack.setBackground(new java.awt.Color(0, 255, 255));
        btnBack.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        btnBack.setText("BACK");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });
        pnlRentMovie.add(btnBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(960, 890, 160, -1));

        lblClient.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        lblClient.setForeground(new java.awt.Color(0, 255, 255));
        lblClient.setText("CLIENT");
        pnlRentMovie.add(lblClient, new org.netbeans.lib.awtextra.AbsoluteConstraints(1310, 540, 100, -1));

        lblMovie.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        lblMovie.setForeground(new java.awt.Color(0, 255, 255));
        lblMovie.setText("MOVIE");
        pnlRentMovie.add(lblMovie, new org.netbeans.lib.awtextra.AbsoluteConstraints(1320, 620, 90, -1));

        btnRent.setBackground(new java.awt.Color(0, 255, 255));
        btnRent.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        btnRent.setText("RENT");
        btnRent.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRentActionPerformed(evt);
            }
        });
        pnlRentMovie.add(btnRent, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 680, 110, -1));

        btnCancel.setBackground(new java.awt.Color(0, 255, 255));
        btnCancel.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        btnCancel.setText("CANCEL");
        btnCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelActionPerformed(evt);
            }
        });
        pnlRentMovie.add(btnCancel, new org.netbeans.lib.awtextra.AbsoluteConstraints(960, 680, 130, -1));

        lblNote.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        lblNote.setForeground(new java.awt.Color(0, 255, 255));
        lblNote.setText("*SYSTEM GENERATES RENTING ID AFTER SUCCESSFUL RENTING OF A MOVIE.");
        pnlRentMovie.add(lblNote, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 170, 810, -1));

        lblRentingId.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        lblRentingId.setForeground(new java.awt.Color(0, 255, 255));
        lblRentingId.setText("RENTING ID");
        pnlRentMovie.add(lblRentingId, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 320, 140, -1));

        txtRentingId.setEditable(false);
        txtRentingId.setBackground(new java.awt.Color(204, 204, 204));
        txtRentingId.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        txtRentingId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtRentingIdActionPerformed(evt);
            }
        });
        pnlRentMovie.add(txtRentingId, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 320, 190, -1));

        ScrollMovieInfo.setBackground(new java.awt.Color(204, 255, 255));

        txtRentingInfo.setEditable(false);
        txtRentingInfo.setBackground(new java.awt.Color(204, 255, 255));
        txtRentingInfo.setColumns(20);
        txtRentingInfo.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        txtRentingInfo.setRows(5);
        ScrollMovieInfo.setViewportView(txtRentingInfo);

        pnlRentMovie.add(ScrollMovieInfo, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 410, 350, 300));

        cmbClients.setBackground(new java.awt.Color(204, 255, 255));
        cmbClients.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        cmbClients.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbClientsActionPerformed(evt);
            }
        });
        pnlRentMovie.add(cmbClients, new org.netbeans.lib.awtextra.AbsoluteConstraints(1480, 530, 320, -1));

        cmbMovies.setBackground(new java.awt.Color(204, 255, 255));
        cmbMovies.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        cmbMovies.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbMoviesActionPerformed(evt);
            }
        });
        pnlRentMovie.add(cmbMovies, new org.netbeans.lib.awtextra.AbsoluteConstraints(1490, 620, 310, -1));

        date_out.setBackground(new java.awt.Color(204, 255, 255));
        pnlRentMovie.add(date_out, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 540, 210, 40));

        lbldateout.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        lbldateout.setForeground(new java.awt.Color(0, 255, 255));
        lbldateout.setText("DATE OUT");
        pnlRentMovie.add(lbldateout, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 480, 120, 40));

        background.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/4000x4000.jpg"))); // NOI18N
        pnlRentMovie.add(background, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 2000, 2000));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlRentMovie, javax.swing.GroupLayout.PREFERRED_SIZE, 2000, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlRentMovie, javax.swing.GroupLayout.PREFERRED_SIZE, 2000, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        this.setVisible(false);
        this.dispose();
        controller.BackHome();
    }//GEN-LAST:event_btnBackActionPerformed

    private void btnRentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRentActionPerformed

        if (movie_id == 0 || client_id == 0) {
            JOptionPane.showMessageDialog(null, "Client and Movie should be selected"); // show message
            return;
        }
        if (rent_id.equalsIgnoreCase("True")) {
            JOptionPane.showMessageDialog(null, "Movie is already rented"); // show message
            return;
        }
        
        if(date_out.getDate()==null){
            JOptionPane.showMessageDialog(null, "date_out is empty"); // show message
            return;
        }
        DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
        String dateout = dateFormat.format(date_out.getDate());

        

        rentMovie(movie_id, client_id, dateout);
        if (model.getRenting_id() != 0 && movieModel.getRent().equalsIgnoreCase("True")) {
            txtRentingId.setText(""+model.getRenting_id());
            JOptionPane.showMessageDialog(null, "Movie is rented successfully. Rending Id is" + model.getRenting_id());
            clearFields();
        }else if (model.getRenting_id() == 0){
             JOptionPane.showMessageDialog(null, "Client has already rented 3 movies");
            clearFields();
        }
    }//GEN-LAST:event_btnRentActionPerformed

    @Override
    public void rentMovie(int movie_id, int client_id, String dateout) {
      
        controller.rentMovie(movie_id, client_id, dateout);

        
        if (model.getRenting_id() != 0 )
        controller.RentMovieUpdate(movie_id);

    }

    @Override
    public void clearFields() {
        if (cmbMovies.getItemCount() > 0) {
            cmbMovies.setSelectedIndex(0);
        }
        if (cmbClients.getItemCount() > 0) {
            cmbClients.setSelectedIndex(0);
        }
        date_out.setDate(null);
        txtRentingId.setText("");

    }

    int movie_id = 0;
    int client_id = 0;
    String rent_id ;

    @Override
    public void setRentingInfo(ArrayList<String> clientInfo, ArrayList<String> movieInfo) {
         txtRentingInfo.setText("");
        for (String client : clientInfo) {
            txtRentingInfo.setText(txtRentingInfo.getText() + client);
        }
        for (String info : movieInfo) {
            txtRentingInfo.setText(txtRentingInfo.getText() + info);
        }
    }

    @Override
    public void setMovieInfo() {

        ArrayList<Movie> movies = movieModel.getMovies();
        movieInfo.clear();
        movieInfo.add("\n\nMovie Info:");
        for (Movie movie : movies) {
            if (movie.getMovie_title().equals(cmbMovies.getSelectedItem().toString())) {
                movie_id = movie.getMovie_id();
                rent_id = movie.getRent();
                movieInfo.add("\nMovie ID: " + movie_id + "\nMovie Title: " + movie.getMovie_title() + "\nMovie Rent: " + (movie.getRent().equalsIgnoreCase("True")?"Rent":"NotRented"));
            }
        }
        setRentingInfo(clientInfo, movieInfo);
    }

    @Override
    public void setClientInfo() {

        ArrayList<Client> clients = clientModel.getClients();
        clientInfo.clear();
        clientInfo.add("Client Info:");
        for (Client client : clients) {
            if (client.getName().equals(cmbClients.getSelectedItem().toString())) {
                client_id = client.getClient_id();
                clientInfo.add("\nClient ID: " + client_id + "\nClient Name: " + client.getName() + "\nClient Deleted: " + (client.getDeleted().equalsIgnoreCase("False")?"Active":"NotActive") );
            }

        }

        setRentingInfo(clientInfo, movieInfo);

    }

    ArrayList<String> clientInfo = new ArrayList<String>();
    ArrayList<String> movieInfo = new ArrayList<String>();

    private void cmbClientsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbClientsActionPerformed
        setClientInfo();
    }//GEN-LAST:event_cmbClientsActionPerformed

    private void cmbMoviesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbMoviesActionPerformed
        setMovieInfo();
    }//GEN-LAST:event_cmbMoviesActionPerformed

    private void btnCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelActionPerformed
        clearFields();
    }//GEN-LAST:event_btnCancelActionPerformed

    private void txtRentingIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtRentingIdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtRentingIdActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RentMoviePageGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane ScrollMovieInfo;
    private javax.swing.JLabel background;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnCancel;
    private javax.swing.JButton btnRent;
    private javax.swing.JComboBox<String> cmbClients;
    private javax.swing.JComboBox<String> cmbMovies;
    private com.toedter.calendar.JDateChooser date_out;
    private javax.swing.JLabel lblClient;
    private javax.swing.JLabel lblHeading;
    private javax.swing.JLabel lblMovie;
    private javax.swing.JLabel lblNote;
    private javax.swing.JLabel lblRentingId;
    private javax.swing.JLabel lbldateout;
    private javax.swing.JPanel pnlRentMovie;
    private javax.swing.JTextField txtRentingId;
    private javax.swing.JTextArea txtRentingInfo;
    // End of variables declaration//GEN-END:variables
}
