package View;

/**
 *
 * @author Nithisha Reddy Boyapati
 */
public interface IAddMoviePageGUI {

    public void addMovie(String movieTitle);

    public void clearFields();
}
