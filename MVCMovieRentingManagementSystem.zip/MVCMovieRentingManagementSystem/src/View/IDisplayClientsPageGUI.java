
package View;

/**
 *
 * @author Nithisha Reddy Boyapati
 */
public interface IDisplayClientsPageGUI {
    
    public void show_Clients();
  
}
