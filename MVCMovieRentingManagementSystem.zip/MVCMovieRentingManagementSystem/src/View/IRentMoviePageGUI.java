package View;

import java.util.ArrayList;

/**
 *
 * @author Nithisha Reddy Boyapati
 */
public interface IRentMoviePageGUI {

    public void setRentingInfo(ArrayList<String> clientInfo, ArrayList<String> movieInfo);

    public void setClientsComboBox();

    public void setMoviesComboBox();

    public void setClientInfo();

    public void setMovieInfo();

    public void clearFields();

    public void rentMovie(int movie_id, int client_id, String datein);
}
